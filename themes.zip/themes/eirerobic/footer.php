<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WP_Bootstrap_Starter
 */

?>
<?php if(!is_page_template( 'blank-page.php' ) && !is_page_template( 'blank-page-with-container.php' )): ?>
			</div><!-- .row -->
		</div><!-- .container -->
	</div><!-- #content --><div class="ftr_wrapper">
    <?php get_template_part( 'footer-widget' ); ?>
	<footer id="colophon" class="site-footer <?php echo wp_bootstrap_starter_bg_class(); ?>" role="contentinfo">
		<div class="container">
           <div class="site-info row">
        <?php if ( is_active_sidebar( 'footer-left' )) : ?>
            <div class="col-12 col-md-5 footer-left text-left pl-0"><?php dynamic_sidebar( 'footer-left' ); ?></div>
        <?php endif; ?>
         <?php if ( is_active_sidebar( 'footer-mid' )) : ?>
            <div class="col-12 col-md-5 footer-mid"><?php dynamic_sidebar( 'footer-mid' ); ?></div>
        <?php endif; ?>
        <?php if ( is_active_sidebar( 'footer-right' )) : ?>
            <div class="col-12 col-md-2 footer-right text-right pr-0"><?php dynamic_sidebar( 'footer-right' ); ?></div>
        <?php endif; ?>
      
</div><!-- close .site-info -->
		</div>
	</footer><!-- #colophon --></div>
<?php endif; ?>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
<script type="text/javascript">
jQuery(window).load(function(){
  jQuery('.our_courses').owlCarousel({
    items:4,
      loop:false,
        margin:20,
        nav:false,
         navText : ["<i class='fa-solid fa-angle-left'></i>","<i class='fa-solid fa-angle-right'></i>"], 
        dots: false,
        center: false,
        touchDrag : false, 
        mouseDrag: true,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav:true
            },
            600:{
                items:2,
                nav:false
            },
            1000:{
                items:4,
                nav:true,
                loop:false
            }
        }
  })
	jQuery('.sec_music .vc_general').click(function(e) {
    
	var link = document.createElement('a');
link.href = '<?php echo get_home_url();?>/jigs/wp-content/uploads/2023/01/IrishVideoClip.mp4';
link.download = "IrishVideoClip.mp4";
link.click();
link.remove();
});
		jQuery(' #vd1 .vc_general').click(function(e) {
    
	var link = document.createElement('a');
link.href = '<?php echo get_home_url();?>/jigs/wp-content/uploads/2023/01/IrishVideoClip.mp4';
link.download = "IrishVideoClip.mp4";
link.click();
link.remove();
});
			jQuery('.intro-vd video').trigger('pause');
	
});
</script>





<script>    

// jQuery(".um-col-alt-b").insertAfter(".um-field-c .um-field-area");
// jQuery(document).ready(function() {
//     jQuery('.jigs_show ul').on('mousewheel', function(e, delta) {
//         e.preventDefault();
//         var newScrollLeft = this.scrollLeft - (delta * 60);
//         jQuery(this).stop().animate({
//             scrollLeft: newScrollLeft
//         }, 100);
//     });
// });


jQuery(document).ready(function() {
    var jigsShowUl = jQuery('.jigs_show ul');
    var isDragging = false;
    var startX;

    jigsShowUl.on('mousedown touchstart', function(e) {
        isDragging = true;
        startX = e.pageX || e.originalEvent.touches[0].pageX;
    });

    jQuery(document).on('mousemove touchmove', function(e) {
        if (!isDragging) return;

        var currentX = e.pageX || e.originalEvent.touches[0].pageX;
        var delta = startX - currentX;

        jigsShowUl.scrollLeft(jigsShowUl.scrollLeft() + delta);
        startX = currentX;
    });

    jQuery(document).on('mouseup touchend', function() {
        isDragging = false;
    });

    jigsShowUl.on('mousewheel', function(e, delta) {
        e.preventDefault();
        var newScrollLeft = jigsShowUl.scrollLeft() - (delta * 60);
        jigsShowUl.stop().animate({
            scrollLeft: newScrollLeft
        }, 50);
    });
});

</script>


<script>

//       jQuery(document).ready(function() {
       
//     var video = jQuery('.main_video_sec video')[0]; // Replace 'yourVideoElementID' with the actual ID of your video element
//     var isVideoPlayed = false;

//     jQuery(video).on('play', function() {
//         isVideoPlayed = true;
//     });
//     jQuery(video).on('pause', function() {
//         isVideoPlayed = false;
//     });
//     jQuery('.btn_stops').on('click', function() {
        
//         jQuery(".btn_stops").addClass("active");
        
//         setTimeout(function() {
//             jQuery(".btn_stops").removeClass("active");
//         }, 600);



//         if (!isVideoPlayed) {
//             video.play();
//             jQuery(".btn_stops a").html('<i class="fa-solid fa-pause"></i>');
//         }else{
//             video.pause();
//             jQuery(".btn_stops a").html('<i class="fa-solid fa-play"></i>');
//         }
//     });



//         var progressBar = jQuery('.videoProgressBar')[0];
//         video.addEventListener('timeupdate', function() {
//             var progressValue = (video.currentTime / video.duration) * 100;
//             progressBar.value = progressValue;
//         });
// });




document.addEventListener('DOMContentLoaded', function() {
    jQuery(document).ready(function() {
        var videos = jQuery('.main_video_sec video');
                
        videos.each(function() {
            var currentVideo = this;
            var playPauseButton = jQuery(currentVideo).siblings('.btn_stops');

            playPauseButton.on('click', function() {
                jQuery(this).addClass("active");

                setTimeout(function() {
                    jQuery(this).removeClass("active");
                }.bind(this), 600);

                // Pause all other videos
                videos.not(currentVideo).each(function() {
                    this.pause();
                    jQuery(this).siblings('.btn_stops').find('a').html('<i class="fa-solid fa-play"></i>');
                });

                if (currentVideo.paused) {
                    currentVideo.play();
                    playPauseButton.find('a').html('<i class="fa-solid fa-pause"></i>');
                } else {
                    currentVideo.pause();
                    playPauseButton.find('a').html('<i class="fa-solid fa-play"></i>');
                }
            });
           
        });
    });
});
</script>

<script>
   document.addEventListener("DOMContentLoaded", function () {
    let currentVideo = null;

    const videoObserver = new IntersectionObserver(handleIntersection, {
        threshold: 0.5, 
    });

    const reels = document.querySelectorAll('.main_video_sec');

    reels.forEach((reel) => {
        videoObserver.observe(reel);
    });

    function handleIntersection(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Video is in the viewport
                if (currentVideo) {
                    currentVideo.pause();
                    currentVideo.currentTime = 0;
                }

                const newVideo = entry.target.querySelector('video');
                    
                    setTimeout(() => {
                        if (newVideo) {
                            newVideo.play();
                            currentVideo = newVideo;
                        }
                    }, 1000);
            }
        });
    }
});
</script>


<script>
function get_urls_of_video(post_id) {
    jQuery.ajax({
        url: "<?php echo admin_url('admin-ajax.php'); ?>",
        method: 'POST',
        data: {
            action: 'get_jigs_pop',
            post_id2: post_id,
        },
        success: function (data) {
            if (data.success && data.data.popupContent) {

                jQuery('.pop_jigs').css("display", "block");
                jQuery('.all_jigs_here_popup').html(data.data.popupContent);
                jQuery('body').css("overflow","hidden");
                loadVideoUrls(post_id);
                
            }
        },
        error: function (error) {
            console.error('AJAX Error:', error);
        }
    });
}

// function loadVideoUrls(post_id) {
//     jQuery.ajax({
//         url: "<?php echo admin_url('admin-ajax.php'); ?>",
//         method: 'POST',
//         data: {
//             action: 'get_video_urls',
//             post_id: post_id,
//         },
//         success: function (data) {
//             if (data.success && data.data.videoUrls && Array.isArray(data.data.videoUrls)) {
//                 var videoUrls = data.data.videoUrls;

//                 var clickedPostContainer = document.querySelector('.all_jigs_heree[data-post-id="' + post_id + '"]');

//                 if (clickedPostContainer) {
//                     var currentVideoContainers = clickedPostContainer.querySelectorAll('.video_jig video');
//                     var video_contner = clickedPostContainer.querySelector('.video_editing_jigs');

//                     videoUrls.forEach(function (videoData, index) {
//                         if (videoData.Enter_file && videoData.Enter_file.url && videoData.Enter_file.ID) {
//                             var id_of_video_url = videoData.Enter_file.ID;
//                             console.log('Video ID:', id_of_video_url);
                            
//                             if (index < currentVideoContainers.length) {
//                                 var url_video_decript = videoData.Enter_file.url;

//                                 var xhr = new XMLHttpRequest();
//                                 xhr.open('GET', url_video_decript, true);
//                                 xhr.responseType = 'blob';

//                                 xhr.onload = function () {
//                                     var reader = new FileReader();
//                                     reader.onloadend = function () {
//                                         currentVideoContainers[index].src = reader.result;
//                                         currentVideoContainers[index].setAttribute('data-id-jigs', id_of_video_url);
//                                     };
//                                     reader.readAsDataURL(xhr.response);
//                                 };

//                                 xhr.send();
//                             }
//                         }
//                     });
//                 }
//             }
//         },
//         error: function (error) {
//             console.error('AJAX Error:', error);
//         }
//     });
// }


function loadVideoUrls(post_id) {
    jQuery.ajax({
        url: "<?php echo admin_url('admin-ajax.php'); ?>",
        method: 'POST',
        data: {
            action: 'get_video_urls',
            post_id: post_id,
        },
        success: function (data) {
            if (data.success && data.data.videoUrls && Array.isArray(data.data.videoUrls)) {
                var videoUrls = data.data.videoUrls;

                var clickedPostContainer = jQuery('.all_jigs_here_popup');

                if (clickedPostContainer) {
                    var currentVideoContainers = clickedPostContainer.find('.video_jig video');
                    var play_pause_btn_rm = clickedPostContainer.find('.play_pause_btn_jigs');
                    var like_data_ID = clickedPostContainer.find('.likes_heart a');
                    var currentVideoIndex = 0;

                    videoUrls.forEach(function (videoData, index) {
                        if (videoData.Enter_file && videoData.Enter_file.url && videoData.Enter_file.ID) {
                            if (index < currentVideoContainers.length) {
                                var url_video_decript = videoData.Enter_file.url;
                                var video_ID_all = videoData.Enter_file.ID;
                                // lastEnterFileID = video_ID_all;
                                var currentVideoElement  = currentVideoContainers[index];
                                currentVideoElement.setAttribute('id', "lst-" + video_ID_all);
                                var lastVideo = videojs(currentVideoElement);
                                var xhr = new XMLHttpRequest();
                                xhr.open('GET', url_video_decript, true);
                                xhr.responseType = 'blob';

                                xhr.onload = function () {
                                    var reader = new FileReader();
                                    reader.onloadend = function () {
                                        currentVideoContainers[index].src = reader.result;
                                        like_data_ID[index].setAttribute('data-id-jigs', video_ID_all);
                                        currentVideoContainers[index].setAttribute('id', "lst-"+ video_ID_all);
                                    };
                                    reader.readAsDataURL(xhr.response);
                                };

                                xhr.send();

                                
                                

                                

                                lastVideo.on('durationchange', function() {
                                    lastVideo.currentTime(0);
                                });

                                
                                
                                lastVideo.on('timeupdate', function() {
                                    if (lastVideo.currentTime() >= 15) {
                                        lastVideo.pause();
                                        play_pause_btn_rm.css("display","none");
                                        
                                            setTimeout(() => {
                                                jQuery(".video_jig button.slick-next.slick-arrow").click();
                                            }, 1500);
                                                

                                            var intervalId = setInterval(checkAndNavigate(lastVideo), 1000);

                                            setTimeout(function() {
                                                clearInterval(intervalId);
                                            }, 1000);   

                                        

                                    } else{
                                        play_pause_btn_rm.css("display","flex");
                                    }

                                    
                                    // lastVideo.on('ended', function() {
                                    //     play_pause_btn_rm.css("display", "flex");
                                    //     jQuery(".video_jig button.slick-next.slick-arrow").click();
                                    // });
                                    
                                    
                                });
                                
              
                            }

                            
                        }
                    });



                    currentVideoContainers.each(function () {
                        this.load();
                    });
                }
            }
        },
        error: function (error) {
            console.error('AJAX Error:', error);
        }
    });
}

function checkAndNavigate(lastVideo) {
    var slider_clid = jQuery(".video_jig button.slick-next.slick-arrow").attr("aria-disabled");

    
    console.log(slider_clid);


    if (slider_clid == "true") {
        //clearInterval(intervalId);  // Stop the interval
            setTimeout(() => {
                jQuery(".jigs_over > a").click();
            }, 1500);
        
    }else if (!slider_clid) {
        setTimeout(() => {
            jQuery(".jigs_over > a").click();
        }, 1500);
    }
}



    // for reals
    document.addEventListener("DOMContentLoaded", function () {
            var videoContainers = document.querySelectorAll('.main_video_sec video');
            var fileInputs = document.querySelectorAll('.get_reel_url');

            videoContainers.forEach(function (videoContainer, index) {
                var fileInput = fileInputs[index].value;

                var xhr = new XMLHttpRequest();
                xhr.open('GET', fileInput, true);

                xhr.responseType = 'blob';

                xhr.onload = function () {
                    var reader = new FileReader();
                    reader.onloadend = function () {
                        videoContainer.src = reader.result;
                    };
                    reader.readAsDataURL(xhr.response);
                };
                xhr.send();
            });
        });
    // fo reals end
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js" integrity="sha512-HGOnQO9+SP1V92SrtZfjqxxtLmVzqZpjFFekvzZVWoiASSQgSr4cw9Kqd2+l8Llp4Gm0G8GIFJ4ddwZilcdb8A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
jQuery('.jigs_over a').click(function(){
    jQuery('.pop_jigs').fadeOut();
    jQuery('.all_jigs_here_popup').html('');
    jQuery('body').css("overflow","unset");
});


jQuery(".all_jigs_heree a").on("click", function () {
    // console.log("done");
    jQuery(".main_video_sec video").each(function() {
        this.pause();
    });
});




</script>


<script>

function validation_reel() {
    var reel_link = jQuery(".file__all_reel").val(); 
    var reel_title = jQuery(".titleS_rl").val();

   
        if (reel_link.trim() === "") {
            jQuery(".file_upload").addClass("add_video_clr");

            jQuery("#upload_reel").click(function(event) {
                event.preventDefault();
            });

            jQuery("#upload_jogs").click(function(event) {
                event.preventDefault();
            });
        } else{
            jQuery(".file_upload").removeClass("add_video_clr");
        }


        if (reel_title.trim() === "") {
            jQuery(".titleS_rl").addClass("add_video_clr");
            
            jQuery("#upload_reel").click(function(event) {
                event.preventDefault();
            });

            jQuery("#upload_jogs").click(function(event) {
                event.preventDefault();
            });

        } else{
            jQuery(".titleS_rl").removeClass("add_video_clr");
        }

}

function get_data_reel(usr_id) {
    var get_data = new FormData();
    get_data.append("action", "reel__show");
    get_data.append("user_ID", usr_id);

    jQuery.ajax({
        url: "<?php echo admin_url('admin-ajax.php'); ?>",
        type: "POST",
        cache: false,
        data: get_data,
        processData: false,
        contentType: false,
        success: function (data) {
            
            jQuery(".jigs_udate_all_time").html(data);
            
        },
        error: function (xhr, status, error) {
            console.error("Error:", error);
        }
    });
}


jQuery("#upload_reel").click(function () {
    var user_ID = jQuery("#user_ID").val();
    var reel_link = jQuery("#reel")[0].files[0]; 
    var reel_chek = jQuery("#reel").val(); 
    var reel_title = jQuery("#reel_title").val();
    
  
    if(reel_title.trim() === ""){

        validation_reel();

    }else if(reel_chek === ""){
        validation_reel();
    }else{
        var formData = new FormData();
        formData.append("action", "send_reels");
        formData.append("user_ID", user_ID);
        formData.append("reel_link", reel_link);
        formData.append("reel_title", reel_title);
        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            datatype: 'json',
            type: "POST",
            cache: false,
            data: formData,
            processData: false,
            contentType: false,
            success: function (data) {

                get_data_reel(user_ID);
                jQuery("#reel").val('');
                jQuery("#reel_title").val('');
                jQuery(".fileNameContainer").html('');
                jQuery(".reeluploads .error_msg").html("");
                jQuery(".reeluploads .sucess_msg").html("<i class='fas fa-check-circle'></i> Reel uploaded Successfully");

                setTimeout(() => {
                    jQuery(".reeluploads .sucess_msg").html("");
                }, 5000);
                    
            },
            error: function (error) {
                    jQuery(".reeluploads .error_msg").html("<i class='fas fa-times-circle'></i> Maximum upload file size: 40 MB.");
            }
        });
    }
});


</script>

<script>

function get_data_jigs(usr_id) {
    var get_data = new FormData();
    get_data.append("action", "jigs__show");
    get_data.append("user_ID", usr_id);

    jQuery.ajax({
        url: "<?php echo admin_url('admin-ajax.php'); ?>",
        type: "POST",
        cache: false,
        data: get_data,
        processData: false,
        contentType: false,
        success: function (data) {
            
            jQuery(".jigs_udate_all_time").html(data);
            
        },
        error: function (xhr, status, error) {
            console.error("Error:", error);
        }
    });
}


 jQuery("#upload_jogs").on("click", function () {
    var User_ID = jQuery('#USER_id').val();
    var pst_ID = jQuery('#post_id').val();
    
    var jigs_video = jQuery('#Jigs')[0].files[0];
    var jig_chek = jQuery("#Jigs").val();
    var jig_title = jQuery("#jigs_title").val();

    if (jig_chek === "") {
        validation_reel();
    } else { 
        if (!pst_ID) {

            // for adding jigs
            var add_jigs = new FormData();
            add_jigs.append("action", "add_Jigs");
            add_jigs.append("jigs_video", jigs_video);
            add_jigs.append("jig_title", jig_title);
            add_jigs.append("User_ID", User_ID);

            jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                dataType: 'json',
                type: "POST",
                cache: false,
                data: add_jigs,
                processData: false,
                contentType: false,
                success: function (data) {

                    get_data_jigs(User_ID);

                    jQuery("#Jigs").val("");
                    jQuery(".reeluploads .sucess_msg").html("<i class='fas fa-check-circle'></i> Jig Uploaded Successfully");
                    jQuery(".fileNameContainer").html('');
                    jQuery(".reeluploads .error_msg").html("");
                    
                    setTimeout(() => {
                        jQuery(".reeluploads .sucess_msg").html("");
                    }, 5000);

                    

                },
                error: function (xhr, status, error) {
                    jQuery(" .reeluploads .error_msg").html("<i class='fas fa-times-circle'></i> Maximum upload file size: 40 MB.");
                }
            });

        } else {
            // for add jigs in its available post
            var update_jigs = new FormData();
            update_jigs.append("action", "update_Jigs");
            update_jigs.append("jigs_video", jigs_video);
            update_jigs.append("pst_ID", pst_ID);

            jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                dataType: 'json',
                type: "POST",
                cache: false,
                data: update_jigs,
                processData: false,
                contentType: false,
                success: function (data) {
                    jQuery("#Jigs").val("");
                    jQuery(".reeluploads .sucess_msg").html("<i class='fas fa-check-circle'></i> New Jig Uploaded Successfully");
                    jQuery(".fileNameContainer").html('');
                    jQuery(".reeluploads .error_msg").html("");

                    get_data_jigs(User_ID);

                    setTimeout(() => {
                        jQuery(".reeluploads .sucess_msg").html("");
                    }, 5000);
                },
                error: function (xhr, status, error) {
                    jQuery(".reeluploads .error_msg").html("<i class='fas fa-times-circle'></i> Maximum upload file size: 40 MB.");
                }
            });
        }
    }
});


    

jQuery(".remove_IT").on("click", function(){
    var agree = confirm("Are you sure you want to delete this file?");

    var User_ID = jQuery('#USER_id').val();
    var post_ID = jQuery('#post_id').val();
    var field_index = jQuery(this).data('index');
    var numberOfChildren = jQuery(".all_jigs_present").find(".rmve_jigs").length;


    if(agree == true){
        var delete_jigs = new FormData();
        delete_jigs.append("action", "delete_Jigs");
        delete_jigs.append("post_ID", post_ID);
        delete_jigs.append("field_index", field_index);
        delete_jigs.append("numberOfChildren", numberOfChildren);

        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            dataType: 'json',
            type: "POST",
            cache: false,
            data: delete_jigs,
            processData: false,
            contentType: false,
            success: function (data) {

                get_data_jigs(User_ID);

                jQuery(".jigs_post_show .sucess_msg").html("<i class='fas fa-check-circle'></i> Jig Deleted Successfully");
                setTimeout(() => {
                    jQuery(".jigs_post_show .sucess_msg").html("");
                }, 5000);
            },
            error: function (xhr, status, error) {
                jQuery(".jigs_post_show .error_msg").html("<i class='fas fa-times-circle'></i> File is Not Deleted.");
            }
        });
    }

});






jQuery(".remove_reel").on("click", function(){
    var agree = confirm("Are you sure you want to delete this file?");

    var User_ID = jQuery('#user_ID').val();
    var post_ID = jQuery(this).data('index');


    if(agree == true){
        var delete_jigs = new FormData();
        delete_jigs.append("action", "delete_reels");
        delete_jigs.append("post_ID", post_ID);

        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            dataType: 'json',
            type: "POST",
            cache: false,
            data: delete_jigs,
            processData: false,
            contentType: false,
            success: function (data) {
                get_data_reel(User_ID);
                jQuery(".jigs_post_show .sucess_msg").html("<i class='fas fa-check-circle'></i> reel Deleted Successfully");
                setTimeout(() => {
                    jQuery(".jigs_post_show .sucess_msg").html("");
                }, 5000);
            },
            error: function (xhr, status, error) {
                jQuery(".jigs_post_show .error_msg").html("<i class='fas fa-times-circle'></i> File is Not Deleted.");
            }
        });
    }

});


jQuery("#update_up_prof").on("click", function () {
    var post_id = jQuery("#post_id").val();
    var user_id = jQuery("#user_id").val();
    var fname = jQuery("#f_name").val();
    var lname = jQuery("#l_name").val();
    var email = jQuery("#email_address").val();
    var p_number = jQuery("#p_number").val();
    var U_state = jQuery("#U_state").val();
    var U_city = jQuery("#U_city").val();
    var U_country = jQuery("#U_country").val();
    var location = jQuery("#location").val();
    var U_bio = jQuery("#U_bio").val();
    var Update_profile_pic = jQuery("#Update_profile_pic")[0].files[0];
    var Update_profile_pic_v = jQuery("#Update_profile_pic").val();
    var featured_image = jQuery("#featured_image").val();



    // profile complition
    var f_value = jQuery("#f_value").val();
    var l_value = jQuery("#l_value").val();
    var email_value = jQuery("#email_value").val();
    var phone_value = jQuery("#phone_value").val();
    var state_value = jQuery("#state_value").val();
    var city_value = jQuery("#city_value").val();
    var country_value = jQuery("#country_value").val();
    var location_value = jQuery("#location_value").val();
    var bio_value = jQuery("#bio_value").val();
    var profile_pic_value = jQuery("#image_value").val();

    if(fname === ""){
        f_value = 0;

    } if(lname === ""){
        l_value = 0;

    } if(email === ""){
        email_value = 0;
        
    } if(p_number === ""){
        phone_value = 0;
        
    } if(U_state === ""){
        state_value = 0;

    } if(U_city === ""){
        city_value = 0;

    } if(U_country === ""){
        country_value = 0;

    } if(location === ""){
        location_value = 0;

    } if(U_bio === ""){
        bio_value = 0;
        
    } if(Update_profile_pic_v === ""){
        if(featured_image){
            profile_pic_value = jQuery("#image_value").val();
            console.log(profile_pic_value);
        }else{
            profile_pic_value = 0;
            console.log(profile_pic_value);
        }
    }
    
var all_value_user = parseInt(f_value) + parseInt(l_value) + parseInt(email_value) + parseInt(phone_value) + parseInt(state_value) + parseInt(city_value) + parseInt(country_value) + parseInt(location_value) + parseInt(bio_value) + parseInt(profile_pic_value);

    var  update_profile = new FormData();
    update_profile.append("action","update_prof");
    update_profile.append("post_id", post_id);
    update_profile.append("user_id", user_id);
    update_profile.append("fname", fname);
    update_profile.append("lname", lname);
    update_profile.append("p_number", p_number);
    update_profile.append("U_state", U_state);
    update_profile.append("U_city", U_city);
    update_profile.append("U_country", U_country);
    update_profile.append("location", location);
    update_profile.append("U_bio", U_bio);
    update_profile.append("all_value_user", all_value_user);
    update_profile.append("Update_profile_pic", Update_profile_pic);
   
    jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            dataType: 'json',
            type: "POST",
            cache: false,
            data: update_profile,
            processData: false,
            contentType: false,
            success: function (data) {
                jQuery(".content_profile .error_msg").html("");
                jQuery(".content_profile .sucess_msg").html("<i class='fas fa-check-circle'></i> Profile Uploaded Successfully");

                setTimeout(() => {
                    jQuery(".content_profile .sucess_msg").html("");
                }, 5000);
                setTimeout(() => {
                    window.location.replace("<?php echo home_url();?>/account/"); 
                }, 6000);
            },
            error: function (xhr, status, error) {
                jQuery(".content_profile .error_msg").html("<i class='fas fa-times-circle'></i> Profile Not Updated");
            }
        });

    
});



jQuery("#Set_up_prof").on("click", function () {
    var post_id = jQuery("#post_ID").val();
    var user_id = jQuery("#user_id").val();
    var fname = jQuery("#f_name").val();
    var lname = jQuery("#l_name").val();
    var email = jQuery("#email_address").val();
    var p_number = jQuery("#p_number").val();
    var U_state = jQuery("#U_state").val();
    var U_city = jQuery("#U_city").val();
    var U_country = jQuery("#U_country").val();
    var location = jQuery("#location").val();
    var U_bio = jQuery("#U_bio").val();
    var Update_profile_pic = jQuery("#profile_pic")[0].files[0];



    // profile complition
    var f_value = jQuery("#f_value").val();
    var l_value = jQuery("#l_value").val();
    var email_value = jQuery("#email_value").val();
    var phone_value = jQuery("#phone_value").val();
    var state_value = jQuery("#state_value").val();
    var city_value = jQuery("#city_value").val();
    var country_value = jQuery("#country_value").val();
    var location_value = jQuery("#location_value").val();
    var bio_value = jQuery("#bio_value").val();
    var profile_pic_value = jQuery("#image_value").val();

    if(fname === ""){
        f_value = 0;

    } else if(lname === ""){
        l_value = 0;

    } else if(email === ""){
        email_value = 0;
        
    } else if(p_number === ""){
        phone_value = 0;
        
    } else if(U_state === ""){
        state_value = 0;

    } else if(U_city === ""){
        city_value = 0;

    } else if(U_country === ""){
        country_value = 0;

    } else if(location === ""){
        location_value = 0;

    } else if(U_bio === ""){
        bio_value = 0;
        
    } else if(Update_profile_pic === ""){
        profile_pic_value = 0;

    }
    
    var all_value_user = parseInt(f_value) + parseInt(l_value) + parseInt(email_value) + parseInt(phone_value) + parseInt(state_value) + parseInt(city_value) + parseInt(country_value) + parseInt(location_value) + parseInt(bio_value) + parseInt(profile_pic_value);



    // end code here
    var  update_profile = new FormData();
    update_profile.append("action","create_prof");
    update_profile.append("post_id", post_id);
    update_profile.append("user_id", user_id);
    update_profile.append("fname", fname);
    update_profile.append("lname", lname);
    update_profile.append("p_number", p_number);
    update_profile.append("U_state", U_state);
    update_profile.append("U_city", U_city);
    update_profile.append("U_country", U_country);
    update_profile.append("location", location);
    update_profile.append("U_bio", U_bio);
    update_profile.append("Update_profile_pic", Update_profile_pic);
    update_profile.append("all_value_user", all_value_user);
   
    jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            dataType: 'json',
            type: "POST",
            cache: false,
            data: update_profile,
            processData: false,
            contentType: false,
            success: function (data) {
                jQuery(".content_profile .error_msg").html("");
                jQuery(".content_profile .sucess_msg").html("<i class='fas fa-check-circle'></i> Profile Uploaded Successfully");

                setTimeout(() => {
                    jQuery(".content_profile .sucess_msg").html("");
                }, 3000);
                
                

            },
            error: function (xhr, status, error) {
                jQuery(".content_profile .error_msg").html("<i class='fas fa-times-circle'></i> Profile Not Updated");
            }
        });

    
});


jQuery(".subscribe_btn").on("click", function (e) {
    var package_ID = jQuery(this).data("package-id");
    var user_who_purch_id = jQuery(this).data("user-who-purch-id");
    var pckg_name = jQuery(this).data("pckg-name");
    var post_ID = jQuery(this).data("post-id");
    var btn = jQuery(".btn__submit_pakage span");

    if(package_ID  && user_who_purch_id){
        e.preventDefault();

        jQuery(this).text("Unsubscribe");
        jQuery(btn).html(`You have Already Subscribed to ${pckg_name}!`);

        setTimeout(() => {
            agree_delete(post_ID, user_who_purch_id);
        }, 2000);
    }

});


function agree_delete(post_ID, user_who_purch_id) {
    
    var agree = confirm("Are you sure you want to unsubscribe? the amount you have submitted will not refunded");   
    if (agree == true) {

        jQuery(this).text("unsubscribing....");

        console.log(user_who_purch_id);

        var delete_pckage_subs = new FormData(); 
        delete_pckage_subs.append("action","delete_order");
        delete_pckage_subs.append("user_who_purch_id",user_who_purch_id);
        delete_pckage_subs.append("post_ID",post_ID);

        jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                dataType: 'json',
                type: "POST",
                cache: false,
                data: delete_pckage_subs,
                processData: false,
                contentType: false,
                success: function (data) {
                    jQuery(".content_profile .error_msg").html("");
                    jQuery(".content_profile .sucess_msg").html("<i class='fas fa-check-circle'></i> Profile Uploaded Successfully");

                    setTimeout(() => {
                        jQuery(".content_profile .sucess_msg").html("");
                    }, 3000);
                    
                    

                },
                error: function (xhr, status, error) {
                    jQuery(".content_profile .error_msg").html("<i class='fas fa-times-circle'></i> Profile Not Updated");
                }
            });

    } 

}

jQuery(".ihc-complete-purchase-button").on("click", function (e) {
    var package_id = jQuery("#package_id").val();
    var lid_ID = jQuery("#lid_ID").val();
    var user_purchased_id = jQuery("#user_purchased_id").val();
    var package_name = jQuery("#package_name").val(); 
    var post_ID = jQuery("#post_ID").val();  

    if(package_id  && user_purchased_id){
        e.preventDefault();  
        jQuery(".msg_span span").html("You have Already Subscribed");
    }
    else{
        // e.preventDefault();  
        var  package_update = new FormData();
        package_update.append("action","package_data_update_post");
        package_update.append("lid_ID", lid_ID);
        package_update.append("package_purchased", "yes");
        package_update.append("package_name", package_name);
        package_update.append("post_ID", post_ID);

        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            dataType: 'json',
            type: "POST",
            cache: false,
            data: package_update,
            processData: false,
            contentType: false,
            success: function (data) {
                console.log("done");
            },
            error: function (xhr, status, error) {
                
            }
        });
        
    }
});




// jQuery(".delete").on("click", function () {
//     var order_id = jQuery(this).data("order-id");
//     var items = jQuery(this).data("items");
//     var subs = jQuery(this).data("subs");

// console.log(order_id);
//     if(order_id){

//     }

// });

</script>


</html>







