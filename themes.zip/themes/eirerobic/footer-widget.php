<?php

if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) {?>
        <div id="footer-widget" class="row m-0 <?php if(!is_theme_preset_active()){ echo 'bg-light'; } ?>">
            <div class="container">
                <div class="row top">
                     <?php if ( is_active_sidebar( 'ftr-top-1' )) : ?>
                        <div class="col-12 col-md-5 ftr-top_wrapper"><?php dynamic_sidebar( 'ftr-top-1' ); ?></div>
                    <?php endif; ?>
                     <?php if ( is_active_sidebar( 'ftr-top-2' )) : ?>
                        <div class="col-12 col-md-7 ftr-top_wrapper-2 pr-0"><?php dynamic_sidebar( 'ftr-top-2' ); ?></div>
                    <?php endif; ?>
                </div>
                <div class="row mid_raw">
<!--                     <?php //if ( is_active_sidebar( 'footer-1' )) : ?>
                        <div class="col-12 col-md-5 ftr-1"><?php //dynamic_sidebar( 'footer-1' ); ?></div>
                    <?php //endif; ?> -->
                    <?php if ( is_active_sidebar( 'footer-2' )) : ?>
                        <div class="col-12 col-md-6 ftr-2"><?php dynamic_sidebar( 'footer-2' ); ?></div>
                    <?php endif; ?>
                    <?php if ( is_active_sidebar( 'footer-3' )) : ?>
                        <div class="col-12 col-md-5 ftr-3"><?php dynamic_sidebar( 'footer-3' ); ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

<?php }