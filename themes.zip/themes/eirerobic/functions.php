<?php
/**
 * WP Bootstrap Starter functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WP_Bootstrap_Starter
 */


if ( ! function_exists( 'wp_bootstrap_starter_setup' ) ) :
   
    
    
    wp_localize_script( 'all_ajax_func', 'pollAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
    wp_enqueue_script( 'all_ajax_func' );



/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function wp_bootstrap_starter_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on WP Bootstrap Starter, use a find and replace
	 * to change 'wp-bootstrap-starter' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'wp-bootstrap-starter', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'wp-bootstrap-starter' ),
	) );
    

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'wp_bootstrap_starter_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

    function wp_boostrap_starter_add_editor_styles() {
        add_editor_style( 'custom-editor-style.css' );
    }
    add_action( 'admin_init', 'wp_boostrap_starter_add_editor_styles' );

}
endif;
add_action( 'after_setup_theme', 'wp_bootstrap_starter_setup' );


/**
 * Add Welcome message to dashboard
 */
function wp_bootstrap_starter_reminder(){
        $theme_page_url = 'https://afterimagedesigns.com/wp-bootstrap-starter/?dashboard=1';

            if(!get_option( 'triggered_welcomet')){
                $message = sprintf(__( 'Welcome to WP Bootstrap Starter Theme! Before diving in to your new theme, please visit the <a style="color: #fff; font-weight: bold;" href="%1$s" target="_blank">theme\'s</a> page for access to dozens of tips and in-depth tutorials.', 'wp-bootstrap-starter' ),
                    esc_url( $theme_page_url )
                );

                printf(
                    '<div class="notice is-dismissible" style="background-color: #6C2EB9; color: #fff; border-left: none;">
                        <p>%1$s</p>
                    </div>',
                    $message
                );
                add_option( 'triggered_welcomet', '1', '', 'yes' );
            }

}
add_action( 'admin_notices', 'wp_bootstrap_starter_reminder' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function wp_bootstrap_starter_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'wp_bootstrap_starter_content_width', 1170 );
}
add_action( 'after_setup_theme', 'wp_bootstrap_starter_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function wp_bootstrap_starter_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'wp-bootstrap-starter' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    register_sidebar( array(
        'name'          => esc_html__( 'Footer 1', 'wp-bootstrap-starter' ),
        'id'            => 'footer-1',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    register_sidebar( array(
        'name'          => esc_html__( 'Footer 2', 'wp-bootstrap-starter' ),
        'id'            => 'footer-2',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    register_sidebar( array(
        'name'          => esc_html__( 'Footer 3', 'wp-bootstrap-starter' ),
        'id'            => 'footer-3',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
    register_sidebar( array(
        'name'          => esc_html__( 'Footer Top 1', 'wp-bootstrap-starter' ),
        'id'            => 'ftr-top-1',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
     register_sidebar( array(
        'name'          => esc_html__( 'Footer Top 2', 'wp-bootstrap-starter' ),
        'id'            => 'ftr-top-2',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
     register_sidebar( array(
        'name'          => esc_html__( 'Footer left', 'wp-bootstrap-starter' ),
        'id'            => 'footer-left',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
      register_sidebar( array(
        'name'          => esc_html__( 'Footer Mid', 'wp-bootstrap-starter' ),
        'id'            => 'footer-mid',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
         register_sidebar( array(
        'name'          => esc_html__( 'Footer right', 'wp-bootstrap-starter' ),
        'id'            => 'footer-right',
        'description'   => esc_html__( 'Add widgets here.', 'wp-bootstrap-starter' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

}
add_action( 'widgets_init', 'wp_bootstrap_starter_widgets_init' );


/**
 * Enqueue scripts and styles.
 */
function wp_bootstrap_starter_scripts() {
	// load bootstrap css
    wp_enqueue_style( 'owl-carousel.min.css', get_template_directory_uri().'/inc/assets/css/owl.carousel.min.css' );
    if ( get_theme_mod( 'cdn_assets_setting' ) === 'yes' ) {
        wp_enqueue_style( 'wp-bootstrap-starter-bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css' );
        wp_enqueue_style( 'wp-bootstrap-starter-fontawesome-cdn', 'https://use.fontawesome.com/releases/v5.15.1/css/all.css' );
    } else {
        wp_enqueue_style( 'wp-bootstrap-starter-bootstrap-css', get_template_directory_uri() . '/inc/assets/css/bootstrap.min.css' );
        wp_enqueue_style( 'wp-bootstrap-starter-fontawesome-cdn', get_template_directory_uri() . '/inc/assets/css/fontawesome.min.css' );
    }
	// load bootstrap css
	// load AItheme styles
	// load WP Bootstrap Starter styles
	wp_enqueue_style( 'wp-bootstrap-starter-style', get_stylesheet_uri() );
      
    wp_enqueue_style( 'owl-default-min.css', get_template_directory_uri().'/inc/assets/css/owl.theme.default.min.css' );
    if(get_theme_mod( 'theme_option_setting' ) && get_theme_mod( 'theme_option_setting' ) !== 'default') {
        wp_enqueue_style( 'wp-bootstrap-starter-'.get_theme_mod( 'theme_option_setting' ), get_template_directory_uri() . '/inc/assets/css/presets/theme-option/'.get_theme_mod( 'theme_option_setting' ).'.css', false, '' );
    }
    if(get_theme_mod( 'preset_style_setting' ) === 'poppins-lora') {
        wp_enqueue_style( 'wp-bootstrap-starter-poppins-lora-font', 'https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i|Poppins:300,400,500,600,700' );
    }
    if(get_theme_mod( 'preset_style_setting' ) === 'montserrat-merriweather') {
        wp_enqueue_style( 'wp-bootstrap-starter-montserrat-merriweather-font', 'https://fonts.googleapis.com/css?family=Merriweather:300,400,400i,700,900|Montserrat:300,400,400i,500,700,800' );
    }
    if(get_theme_mod( 'preset_style_setting' ) === 'poppins-poppins') {
        wp_enqueue_style( 'wp-bootstrap-starter-poppins-font', 'https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700' );
    }
    if(get_theme_mod( 'preset_style_setting' ) === 'roboto-roboto') {
        wp_enqueue_style( 'wp-bootstrap-starter-roboto-font', 'https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i' );
    }
    if(get_theme_mod( 'preset_style_setting' ) === 'arbutusslab-opensans') {
        wp_enqueue_style( 'wp-bootstrap-starter-arbutusslab-opensans-font', 'https://fonts.googleapis.com/css?family=Arbutus+Slab|Open+Sans:300,300i,400,400i,600,600i,700,800' );
    }
    if(get_theme_mod( 'preset_style_setting' ) === 'oswald-muli') {
        wp_enqueue_style( 'wp-bootstrap-starter-oswald-muli-font', 'https://fonts.googleapis.com/css?family=Muli:300,400,600,700,800|Oswald:300,400,500,600,700' );
    }
    if(get_theme_mod( 'preset_style_setting' ) === 'montserrat-opensans') {
        wp_enqueue_style( 'wp-bootstrap-starter-montserrat-opensans-font', 'https://fonts.googleapis.com/css?family=Montserrat|Open+Sans:300,300i,400,400i,600,600i,700,800' );
    }
    if(get_theme_mod( 'preset_style_setting' ) === 'robotoslab-roboto') {
        wp_enqueue_style( 'wp-bootstrap-starter-robotoslab-roboto', 'https://fonts.googleapis.com/css?family=Roboto+Slab:100,300,400,700|Roboto:300,300i,400,400i,500,700,700i' );
    }
    if(get_theme_mod( 'preset_style_setting' ) && get_theme_mod( 'preset_style_setting' ) !== 'default') {
        wp_enqueue_style( 'wp-bootstrap-starter-'.get_theme_mod( 'preset_style_setting' ), get_template_directory_uri() . '/inc/assets/css/presets/typography/'.get_theme_mod( 'preset_style_setting' ).'.css', false, '' );
    }
    //Color Scheme
    /*if(get_theme_mod( 'preset_color_scheme_setting' ) && get_theme_mod( 'preset_color_scheme_setting' ) !== 'default') {
        wp_enqueue_style( 'wp-bootstrap-starter-'.get_theme_mod( 'preset_color_scheme_setting' ), get_template_directory_uri() . '/inc/assets/css/presets/color-scheme/'.get_theme_mod( 'preset_color_scheme_setting' ).'.css', false, '' );
    }else {
        wp_enqueue_style( 'wp-bootstrap-starter-default', get_template_directory_uri() . '/inc/assets/css/presets/color-scheme/blue.css', false, '' );
    }*/

	wp_enqueue_script('jquery');

    // Internet Explorer HTML5 support
    wp_enqueue_script( 'html5hiv',get_template_directory_uri().'/inc/assets/js/html5.js', array(), '3.7.0', false );
    wp_script_add_data( 'html5hiv', 'conditional', 'lt IE 9' );

	// load bootstrap js
    wp_enqueue_script('owl-carousel.min.js',get_template_directory_uri().'/inc/assets/js/owl.carousel.min.js');
    if ( get_theme_mod( 'cdn_assets_setting' ) === 'yes' ) {
        wp_enqueue_script('wp-bootstrap-starter-popper', 'https://cdn.jsdelivr.net/npm/popper.js@1/dist/umd/popper.min.js', array(), '', true );
    	wp_enqueue_script('wp-bootstrap-starter-bootstrapjs', 'https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js', array(), '', true );
    } else {
        wp_enqueue_script('wp-bootstrap-starter-popper', get_template_directory_uri() . '/inc/assets/js/popper.min.js', array(), '', true );
           
        wp_enqueue_script('wp-bootstrap-starter-bootstrapjs', get_template_directory_uri() . '/inc/assets/js/bootstrap.min.js', array(), '', true );
    }
    wp_enqueue_script('wp-bootstrap-starter-themejs', get_template_directory_uri() . '/inc/assets/js/theme-script.min.js', array(), '', true );
	wp_enqueue_script( 'wp-bootstrap-starter-skip-link-focus-fix', get_template_directory_uri() . '/inc/assets/js/skip-link-focus-fix.min.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'wp_bootstrap_starter_scripts' );



/**
 * Add Preload for CDN scripts and stylesheet
 */
function wp_bootstrap_starter_preload( $hints, $relation_type ){
    if ( 'preconnect' === $relation_type && get_theme_mod( 'cdn_assets_setting' ) === 'yes' ) {
        $hints[] = [
            'href'        => 'https://cdn.jsdelivr.net/',
            'crossorigin' => 'anonymous',
        ];
        $hints[] = [
            'href'        => 'https://use.fontawesome.com/',
            'crossorigin' => 'anonymous',
        ];
    }
    return $hints;
} 

add_filter( 'wp_resource_hints', 'wp_bootstrap_starter_preload', 10, 2 );



function wp_bootstrap_starter_password_form() {
    global $post;
    $label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
    $o = '<form action="' . esc_url( home_url( 'wp-login.php?action=postpass', 'login_post' ) ) . '" method="post">
    <div class="d-block mb-3">' . __( "To view this protected post, enter the password below:", "wp-bootstrap-starter" ) . '</div>
    <div class="form-group form-inline"><label for="' . $label . '" class="mr-2">' . __( "Password:", "wp-bootstrap-starter" ) . ' </label><input name="post_password" id="' . $label . '" type="password" size="20" maxlength="20" class="form-control mr-2" /> <input type="submit" name="Submit" value="' . esc_attr__( "Submit", "wp-bootstrap-starter" ) . '" class="btn btn-primary"/></div>
    </form>';
    return $o;
}
add_filter( 'the_password_form', 'wp_bootstrap_starter_password_form' );



/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load plugin compatibility file.
 */
require get_template_directory() . '/inc/plugin-compatibility/plugin-compatibility.php';

/**
 * Load custom WordPress nav walker.
 */
if ( ! class_exists( 'wp_bootstrap_navwalker' )) {
    require_once(get_template_directory() . '/inc/wp_bootstrap_navwalker.php');
}


// header links
function header_links(){ ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<?php }

// header links and



function create_courses() {
register_post_type( 'courses',
  // CPT Options
      array(
          'labels' => array(
              'name' => __( 'Our Courses' ),
              'singular_name' => __( 'courses' )
          ),
          'public' => true,
          'has_archive' => true,
          'rewrite' => array('slug' => 'courses'),
          'can_export'          => true,
          'supports'            => array( 'title','editor','thumbnail','excerpt'),
          'publicly_queryable'  => true,
          'menu_icon' => 'dashicons-admin-site-alt'
      )
  );
}
// Hooking up our function to theme setup
add_action( 'init', 'create_courses' );
//post-displal-slider
function getcourses(){
        $args = array(
            'post_type' => 'courses',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'ASC',
        );
        $loop = new WP_Query( $args );
        ?>
    <div  class="owl-carousel owl-theme our_courses">
        <?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
            <div class="courses_weapper">
                <div class="boxer">
                        <div class="f-image"><?php echo get_the_post_thumbnail();?></div>
                        <div class="info-wrapper">
                            <h3 class="course__title"><?php echo get_the_title(); ?></h3>
                              <div class="user_review"><p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p></div>
                              <div class="rating_wrapper">
                                   <div class="brand_log">
                                        <?php $image = get_field('brand_logo'); if( !empty( $image ) ): ?>
                                        <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" /><?php endif; ?>
                                        <span class="rating_count">5</span>
                                 </div>
                             </div>
                        </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    <?php    wp_reset_query();
    ?>
<?php
}
add_shortcode('getcourses', 'getcourses'); 


//Blog
function getnews(){
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => 1,
            'orderby' => 'date',
            'order' => 'ASC',
        );
        $loop = new WP_Query( $args );
        ?>
    <div  class="row our_blog">
        <?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
            <div class="col-md-12 frst_box">
                <div class="boxer">
                        <div class="f-image"><?php echo get_the_post_thumbnail();?></div>
                        <div class="info-wrapper">
                            <h3 class="course__title"><?php echo get_the_title(); ?></h3>
                              <div class="user_review"><p><?php echo wp_trim_words(get_the_excerpt(), 60); ?></p></div>
                               <a class="news_btn_top" href="<?php echo get_the_permalink();?>">explore more</a>
                        </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    <?php    wp_reset_query();
    ?>
<?php
}
add_shortcode('getnews', 'getnews');
function getnews_btm(){
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'ASC',
        );
        $loop = new WP_Query( $args );
        ?>
    <div  class="row our_blog">
        <?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
            <div class="col-md-12 btm_box">
                <div class="boxer">
                        <div class="f-image"><?php echo get_the_post_thumbnail();?></div>
                        <div class="info-wrapper">
                            <h3 class="course__title"><?php echo get_the_title(); ?></h3>
                              <div class="user_review"><p><?php echo wp_trim_words(get_the_excerpt(), 30); ?></p></div>
                              <a class="news_btn" href="<?php echo get_the_permalink();?>">explore more</a>
                        </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    <?php    wp_reset_query();
    ?>
<?php
}
add_shortcode('getnews_btm', 'getnews_btm');
function getnews_btm_inner(){
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'ASC',
        );
        $loop = new WP_Query( $args );
        ?>
    <div  class="row our_blog">
        <?php while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
            <div class="col-md-4 btm_box">
                <div class="boxer">
                        <div class="f-image"><?php echo get_the_post_thumbnail();?></div>
                        <div class="info-wrapper">
                            <h3 class="course__title"><?php echo get_the_title(); ?></h3>
                              <div class="user_review"><p><?php echo wp_trim_words(get_the_excerpt(), 30); ?></p></div>
                              <a class="news_btn" href="<?php echo get_the_permalink();?>">explore more</a>
                        </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    <?php    wp_reset_query();
    ?>
<?php
}
add_shortcode('getnews_btm_inner', 'getnews_btm_inner');      







function create_jigs() {
    register_post_type( 'jigs',
          array(
              'labels' => array(
                  'name' => __( 'jigs' ),
                  'singular_name' => __( 'jigs' )
              ),
              'public' => true,
              'has_archive' => false,
              'show_in_nav_menus' => false,
              'exclude_from_search' => true,
              'rewrite' => array('slug' => 'jigs'),
              'can_export'          => true,
              'supports'            => array( 'title','editor','thumbnail','excerpt'),
              'publicly_queryable'  => true,
              'menu_icon' => 'dashicons-admin-site-alt'
          )
      );


      register_post_type( 'reels',
          array(
              'labels' => array(
                  'name' => __( 'reels' ),
                  'singular_name' => __( 'reels' )
              ),
              'public' => true,
              'show_in_nav_menus' => false,
              'exclude_from_search' => true,
              'has_archive' => false,
              'rewrite' => array('slug' => 'reels'),
              'can_export'          => true,
              'supports'            => array( 'title','editor','thumbnail','excerpt'),
              'publicly_queryable'  => true,
              'menu_icon' => 'dashicons-admin-site-alt'
          )
      );


      register_post_type( 'all_user',
          array(
              'labels' => array(
                  'name' => __( 'all user' ),
                  'singular_name' => __( 'all user' )
              ),
              'public' => true,
              'show_in_nav_menus' => false,
              'exclude_from_search' => true,
              'has_archive' => false,
              'rewrite' => array('slug' => 'all_user'),
              'can_export'          => true,
              'supports'            => array( 'title','editor','thumbnail','excerpt'),
              'publicly_queryable'  => true,
              'menu_icon' => 'dashicons-admin-site-alt'
          )
      );
    }
add_action( 'init', 'create_jigs' );

add_action( 'template_redirect', 'wpse_128636_redirect_post' );

function wpse_128636_redirect_post() {
    if ( is_singular( 'reels' ) || is_singular( 'all_user' ) || is_singular( 'jigs' ) ) {
        wp_redirect( home_url(), 301 );
        exit;
    }

    
}
add_action( 'template_redirect', 'archive_redirect' );

function archive_redirect() {
    if ( is_post_type_archive( 'reels' ) || is_post_type_archive( 'all_user' ) || is_post_type_archive( 'jigs' ) ) {
        wp_redirect( home_url(), 301 );
        exit;
    }

    
}


function get_video_urls_handler() {
    $post_id = $_POST['post_id'];
    
    $video_files = get_field('video_jigs', $post_id);

    wp_send_json_success(array('videoUrls' => $video_files));
}

add_action('wp_ajax_get_video_urls', 'get_video_urls_handler');
add_action('wp_ajax_nopriv_get_video_urls', 'get_video_urls_handler');



    function get_jigs_all(){

        global $current_user;
        

        $user_id = $current_user->ID;
        

        $args = array(
            'post_type' => 'jigs',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'ASC',
        );


        $args2 = array(
            'post_type' => 'all_user',
            'author'        =>  $user_id,
            'orderby'       =>  'post_date',
            'order'         =>  'ASC' 
        );

        $all_POSt = get_posts( $args2 );


        $loop = new WP_Query( $args );
            

            $package_purchased = get_field("package_purchased", $all_POSt[0] -> ID);
        ?>
        <ul>
            <?php
             if(!is_user_logged_in()){ ?>
                <li class="add_jigssss">
                    <a href="<?php echo home_url();?>/login"><i class="fa-solid fa-plus"></i> <span>Add Jig</span></a>
                </li>
            <?php } else{
                        if($package_purchased === "no"){ ?>
                            <li class="add_jigssss">
                                <a data-id_subs_user="<?php echo $user_id;?>" href="<?php echo home_url();?>/subscriptions/"><i class="fa-solid fa-plus"></i> <span>Add Jig</span></a>
                            </li>
                        <?php }else{ ?>
                            <li class="add_jigssss">
                                <a href="<?php echo home_url();?>/upload-jigs"><i class="fa-solid fa-plus"></i> <span>Add Jig</span></a>
                            </li>
                        <?php } 
                    } ?>
            <?php 

            while ( $loop->have_posts() ) : 
                $loop->the_post(); 
                ?>
            <li class="all_jigs_heree" data-post-id="<?php echo get_the_ID();?>">
                <a id="<?php echo get_the_id();?>" href="javascript:void(0);" onclick="get_urls_of_video(this.id)">
                    <img src="<?php echo home_url(); ?>/jigs/wp-content/uploads/2023/12/usr.jpg">
                    <span><?php echo get_the_title(); ?></span>
                </a>
            </li>
            <?php endwhile; ?>
        </ul>
    <?php    
    wp_reset_query();
    ?>
    <?php
    } 
    add_shortcode('jigs_short', 'get_jigs_all');   
    


    add_action('wp_ajax_get_jigs_pop', 'get_jigs_popup');
add_action('wp_ajax_nopriv_get_jigs_pop', 'get_jigs_popup');

function get_jigs_popup() {
    $jigs_id = $_POST["post_id2"];
    ob_start();
    ?>
    
    <div class="video_jig">
        <?php
        $get_jigs = get_field("video_jigs", $jigs_id);
        $counter = 0;
        foreach ($get_jigs as $key => $get_jig) { ?>
        <div class="video_editing_jigs">
            <video controls type="video/mp4" autoplay class="jggs"></video>
            <div class="play_pause_btn_jigs">
                <a href="javascript:void(0);"><i class="fa-solid fa-pause"></i></a>
            </div>
            <div class="likes_heart">
                <a href="javsscript:void(0);">
                    <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512"><path d="M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z"/></svg>
                </a>
                <span>1</span>
            </div>
            <p class="video_abs"></p>
        </div>
        <?php } ?>
    </div>

    <script>
        jQuery('.video_jig').slick({
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            swipe: false,
            touchMove: false,
            prevArrow: '<button class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
            nextArrow: '<button class="slick-next"><i class="fas fa-chevron-right"></i></button>',
        });
       
jQuery(document).ready(function() {
    var videos_jigs = jQuery('.video_editing_jigs video');
    
    videos_jigs.each(function() {
        var currentVideo_2 = this;
        var playPauseButton_jigs = jQuery(currentVideo_2).siblings('.play_pause_btn_jigs');

        playPauseButton_jigs.on('click', function() {
            jQuery(this).addClass("active");

            setTimeout(function() {
                jQuery(playPauseButton_jigs).removeClass("active"); 
            }, 600);

            videos_jigs.not(currentVideo_2).each(function() {
                this.pause();
                jQuery(this).siblings('.play_pause_btn_jigs').find('a').html('<i class="fa-solid fa-play"></i>');
            });

            if (currentVideo_2.paused) {
                currentVideo_2.play();
                playPauseButton_jigs.find('a').html('<i class="fa-solid fa-pause"></i>');
            } else {
                currentVideo_2.pause();
                playPauseButton_jigs.find('a').html('<i class="fa-solid fa-play"></i>');
            }
        });
    });
});



jQuery(document).ready(function() {
    let currentVideo_jigss = null;

    jQuery(".video_jig").on('init afterChange', function(event, slick, currentSlide){
        const allVideos = document.querySelectorAll('.video_jig video');
        allVideos.forEach(video => {
            video.pause();
            video.currentTime = 0;
        });

        const currentSlideVideo = jQuery(".video_jig").find(`.slick-slide[data-slick-index="${currentSlide}"] video`);
               
        setTimeout(() => {
            if (currentSlideVideo.length > 0) {
                currentSlideVideo.get(0).play();
                currentVideo_jigss = currentSlideVideo.get(0);
                
                // currentVideo_jigss.addEventListener('timeupdate', function() {
                //     if (currentVideo_jigss.currentTime >= 10) {
                //         const finishTime = currentVideo_jigss.currentTime;
                //         console.log('Finish Time:', finishTime);
                //     }
                // });
            }
        }, 1000);
    });
});


    </script>
    <?php
    $popup_content = ob_get_clean();
    wp_send_json_success(array('popupContent' => $popup_content));
}   
    

function get_all_reels(){
    $args = array(
        'post_type' => 'reels',
        'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'ASC',
    );
    $loop = new WP_Query( $args );
    ?>
    <div class="col-lg-12 col-sm-12 sld">
        <?php while ( $loop->have_posts() ) : 
            $loop->the_post(); 

            $post_id = get_the_ID();
            $post_date = get_the_time('Y-m-d H:i:s', $post_id);
            $post_datetime = new DateTime($post_date);
            $current_datetime = new DateTime();
            $time_difference = $current_datetime->diff($post_datetime);
            // echo format_time_difference($time_difference);
            $time_string = '';
            
            ?>
        <div class="main_video_sec">
            <?php 
                $get_vidoe = get_field("reels");
                $user_id = get_field("user_id");
            ?>      
                
            <video controls autoplay type="video/mp4">
                <input type="hidden" value="<?php echo $get_vidoe["url"];?>" class="get_reel_url">
            </video>
            <div class="btn_stops">
                <a href="javascript:void(0);"><i class="fa-solid fa-pause"></i></a>
            </div>
            <div class="video_reel_content">
                <div class="row">   
                    <div class="col-lg-8 col-md-12 col-sm-12 som_content_reel">
                        <h4><?php echo get_the_title();?></h4>
                        <p><?php echo get_the_excerpt();?></p>
                        <ul>
                            <li><i class="fa-solid fa-eye"></i> 120 k</li>
                            <li><i class="fa-solid fa-heart"></i> 12 k</li>
                            <li><i class="fa-regular fa-clock"></i> <?php 
                                if ($time_difference->y > 0) {
                                    $time_string .= $time_difference->y . ' year' . ($time_difference->y > 1 ? 's' : '') . ' ago';
                                    echo $time_string;
                                } elseif ($time_difference->m > 0) {
                                    $time_string .= $time_difference->m . ' month' . ($time_difference->m > 1 ? 's' : '') . ' ago';
                                    echo $time_string;
                                } elseif ($time_difference->d > 0) {
                                    $time_string .= $time_difference->d . ' day' . ($time_difference->d > 1 ? 's' : '') . ' ago';
                                    echo $time_string;
                                } elseif ($time_difference->h > 0) {
                                    $time_string .= $time_difference->h . ' hour' . ($time_difference->h > 1 ? 's' : '') . ' ago';
                                    echo $time_string;
                                } elseif ($time_difference->i > 0) {
                                    $time_string .= $time_difference->i . ' minute' . ($time_difference->i > 1 ? 's' : '') . ' ago';
                                    echo $time_string;
                                } else {
                                    $time_string .= 'just now';
                                    echo $time_string;
                                }
                                ?></li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="all_liking_function">
                            <ul>
                                <input type="hidden" id="user_ID_reels" value="<?php echo $user_id;?>">
                                <input type="hidden" id="post_ID_reels" value="<?php echo get_the_ID();;?>">
                                <li>
                                    <a href="javascript:void(0);" class="liking_reels">
                                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512"><path d="M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z"/></svg>
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512"><path d="M64 0C28.7 0 0 28.7 0 64V352c0 35.3 28.7 64 64 64h96v80c0 6.1 3.4 11.6 8.8 14.3s11.9 2.1 16.8-1.5L309.3 416H448c35.3 0 64-28.7 64-64V64c0-35.3-28.7-64-64-64H64z"/></svg>
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <svg xmlns="http://www.w3.org/2000/svg" height="16" width="14" viewBox="0 0 448 512"><path d="M0 80V229.5c0 17 6.7 33.3 18.7 45.3l176 176c25 25 65.5 25 90.5 0L418.7 317.3c25-25 25-65.5 0-90.5l-176-176c-12-12-28.3-18.7-45.3-18.7H48C21.5 32 0 53.5 0 80zm112 32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <form action="">
                            <input type="text" class="form-control comment_form" placeholder="Comment" id="comment_here">
                            <button type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 512 512"><path d="M498.1 5.6c10.1 7 15.4 19.1 13.5 31.2l-64 416c-1.5 9.7-7.4 18.2-16 23s-18.9 5.4-28 1.6L284 427.7l-68.5 74.1c-8.9 9.7-22.9 12.9-35.2 8.1S160 493.2 160 480V396.4c0-4 1.5-7.8 4.2-10.7L331.8 202.8c5.8-6.3 5.6-16-.4-22s-15.7-6.4-22-.7L106 360.8 17.7 316.6C7.1 311.3 .3 300.7 0 288.9s5.9-22.8 16.1-28.7l448-256c10.7-6.1 23.9-5.5 34 1.4z"/></svg>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
<?php    
wp_reset_query();
?>
<?php
} 
add_shortcode('reelS_short', 'get_all_reels'); 
    
    
function jigs_post(){
    global $all_user_id;    
    $args = array(
        'post_type' => 'jigs',
        'posts_per_page' => 1,
        'orderby' => 'date',
        'order' => 'ASC',
        'meta_query' => array(
            array(
                'key' => 'user_id', 
                'value' => $all_user_id,
                'compare' => '=',
            ),
        ),
    );
    
    $posts = new WP_Query($args);?>
    <?php if ($posts->have_posts()) {?>
        
        <div class="jigs_post_show">
            <?php while ($posts->have_posts()) {
            $posts->the_post();?>
            <input type="hidden" id="post_id" value= "<?php echo get_the_ID();?>">
            <div class="sucess_msg"></div>
            <div class="error_msg"></div>
            <?php $update_jigs = get_field('video_jigs');?>
                <div class="row all_jigs_present">
                    <?php if ($update_jigs) { 
                        foreach ($update_jigs as $index => $update_jig) {
                            $video_jig_url = $update_jig['Enter_file']; ?>
                            <div class="col-lg-4 col-md-6 col-sm-12 rmve_jigs">
                                <div class="field_wrapper">
                                    <div class="video_jigs_all">
                                        <video src="<?php echo $video_jig_url['url']; ?>" muted autoplay control loop></video>
                                        <div class="update_fields">
                                            <a href="javascript:void(0);" class="remove_IT" data-index="<?php echo $index + 1; ?>"><i class="fas fa-times-circle"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                        }
                    }?>
                </div>
        <?php } ?>

        </div>

        <?php wp_reset_postdata();
    } else {
        echo '<h6>No jigs found.</h6>';
    }
} 
add_shortcode('jigs_post', 'jigs_post');


add_action('wp_ajax_jigs__show', 'jigs__show');
add_action('wp_ajax_nopriv_jigs__show', 'jigs__show');
function jigs__show(){
    $all_user_id = $_POST["user_ID"];    
    $args = array(
        'post_type' => 'jigs',
        'posts_per_page' => 1,
        'orderby' => 'date',
        'order' => 'ASC',
        'meta_query' => array(
            array(
                'key' => 'user_id', 
                'value' => $all_user_id,
                'compare' => '=',
            ),
        ),
    );
    
    
    $posts = new WP_Query($args);?>
    <?php if ($posts->have_posts()) {?>
        
        <div class="jigs_post_show">
            <?php while ($posts->have_posts()) {
            $posts->the_post();?>
            <input type="hidden" id="post_id" value= "<?php echo get_the_ID();?>">
            <div class="sucess_msg"></div>
            <div class="error_msg"></div>
            <?php $update_jigs = get_field('video_jigs');?>
                <div class="row all_jigs_present">
                    <?php if ($update_jigs) { 
                        foreach ($update_jigs as $index => $update_jig) {
                            $video_jig_url = $update_jig['Enter_file']; ?>
                            <div class="col-lg-4 col-md-6 col-sm-12 rmve_jigs">
                                <div class="field_wrapper">
                                    <div class="video_jigs_all">
                                        <video src="<?php echo $video_jig_url['url']; ?>" muted autoplay control loop></video>
                                        <div class="update_fields">
                                            <a href="javascript:void(0);" class="remove_IT" data-index="<?php echo $index + 1; ?>"><i class="fas fa-times-circle"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                        }
                    }?>
                </div>
        <?php } ?>
        </div>
        <?php wp_reset_postdata();
    } else {
        echo '<h6>No jigs found.</h6>';
    }

    exit();
} 



add_action('wp_ajax_send_reels', 'send_reels');
add_action('wp_ajax_nopriv_send_reels', 'send_reels');
function send_reels(){

    $user_ID = $_POST['user_ID'];
    $title_post = $_POST['reel_title'];

    $reel_link = $_FILES["reel_link"];

    $reel_post = array(
        'post_type' => 'reels',
        'post_title' => $title_post,
        // 'post_content' => $content,
        'post_status' => 'publish',
        'rewrite' => array('slug' => sanitize_title($title_post))
    );


   
    $post_id = wp_insert_post($reel_post);


    if ( !function_exists('wp_handle_upload') ) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }
    
    $movefile = wp_handle_upload($reel_link, array('test_form' => false));
    if ($movefile && !isset($movefile['error'])) {
        $wp_upload_dir = wp_upload_dir();
        $attachment = array(
            'guid' => $wp_upload_dir['url'] . '/' . basename($movefile['file']),
            'post_mime_type' => $movefile['type'],
            'post_title' => preg_replace('/\.[^.]+$/', "", basename($movefile['file'])),
            'post_content' => ""
        );
        $attach_id = wp_insert_attachment($attachment, $movefile['file']);
        update_field('reels', $attach_id, $post_id);
    }

    update_field('user_id', $user_ID, $post_id);
    update_field('Enter_file', $user_ID, $post_id);

    $age = array("post" => "uploaded");
    echo json_encode($age);
    exit();
}

add_action('wp_ajax_update_Jigs', 'update_Jigs');
add_action('wp_ajax_nopriv_update_Jigs', 'update_Jigs');
function update_Jigs() {
    $jig_link = $_FILES["jigs_video"];
    $jigs_post_ID =  $_POST["pst_ID"];

    if ( !function_exists('wp_handle_upload') ) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }
    
    $movefile = wp_handle_upload($jig_link, array('test_form' => false));
    if ($movefile && !isset($movefile['error'])) {
        $wp_upload_dir = wp_upload_dir();
        $attachment = array(
            'guid' => $wp_upload_dir['url'] . '/' . basename($movefile['file']),
            'post_mime_type' => $movefile['type'],
            'post_title' => preg_replace('/\.[^.]+$/', "", basename($movefile['file'])),
            'post_content' => ""
        );
        $attach_id = wp_insert_attachment($attachment, $movefile['file']);
        add_row('video_jigs', $attach_id, $jigs_post_ID);
    }
    $existing_values = get_field('video_jigs', $jigs_post_ID);
    $existing_values[] = array('Enter_file' => $attach_id);
    update_field('video_jigs', $existing_values, $jigs_post_ID);

    $age = array("post" => "uploaded");
    echo json_encode($age);
    exit;
}


add_action('wp_ajax_add_Jigs', 'add_Jigs');
add_action('wp_ajax_nopriv_add_Jigs', 'add_Jigs');
function add_Jigs() {
    $user_ID = $_POST['User_ID'];
    $title_jig = $_POST['jig_title'];

    $jig_link = $_FILES["jigs_video"];

    $jig_post = array(
        'post_type' => 'jigs',
        'post_title' => $title_jig,
        // 'post_content' => $content,
        'post_status' => 'publish',
        'rewrite' => array('slug' => sanitize_title($title_jig))
    );


   
    $post_id = wp_insert_post($jig_post);


    if ( !function_exists('wp_handle_upload') ) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }
    
    $movefile = wp_handle_upload($jig_link, array('test_form' => false));
    if ($movefile && !isset($movefile['error'])) {
        $wp_upload_dir = wp_upload_dir();
        $attachment = array(
            'guid' => $wp_upload_dir['url'] . '/' . basename($movefile['file']),
            'post_mime_type' => $movefile['type'],
            'post_title' => preg_replace('/\.[^.]+$/', "", basename($movefile['file'])),
            'post_content' => ""
        );
        $attach_id = wp_insert_attachment($attachment, $movefile['file']);
        update_field('video_jigs', $attach_id, $post_id);
    }
    $existing_values = get_field('video_jigs', $post_id);
    $existing_values[] = array('Enter_file' => $attach_id);
    update_field('video_jigs', $existing_values, $post_id);


    update_field('user_id', $user_ID, $post_id);

    $age = array("post" => "uploaded");
    echo json_encode($age);
    exit;
}


add_action('wp_ajax_delete_Jigs', 'delete_Jigs');
add_action('wp_ajax_nopriv_delete_Jigs', 'delete_Jigs');
function delete_Jigs() {
    $post_ID = $_POST["post_ID"];
    $field_index = $_POST["field_index"];
    $child_number = $_POST["numberOfChildren"];

    delete_row("video_jigs", $field_index, $post_ID);

   
    
    if($child_number == 1){
        wp_delete_post( $post_ID, true);
    }

    $response = array("status" => $child_number);
    // echo json_encode($response);
    wp_send_json($response);
    exit;
}






  
function reel_post(){
    global $user_id;    
    $args = array(
        'post_type' => 'reels',
        'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'ASC',
        'meta_query' => array(
            array(
                'key' => 'user_id', 
                'value' => $user_id,
                'compare' => '=',
            ),
        ),
    );
    
    $posts = new WP_Query($args);?>
    <?php if ($posts->have_posts()) {?>
        <div class="jigs_post_show">
            
            <div class="sucess_msg"></div>
            <div class="error_msg"></div>
            <div class="row all_jigs_present">
                <?php while ($posts->have_posts()) {
                $posts->the_post();?>
                    <?php $update_jigs = get_field('reels');?>
                        <div class="col-lg-4 col-md-6 col-sm-12 rmve_jigs">
                            <div class="field_wrapper">
                                <div class="video_jigs_all">
                                    <video src="<?php echo $update_jigs['url']; ?>" muted autoplay control loop></video>
                                    <div class="update_fields">
                                        <a href="javascript:void(0);" class="remove_reel" data-index="<?php echo get_the_ID(); ?>"><i class="fas fa-times-circle"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php } ?>
            </div>
        </div>

        <?php wp_reset_postdata();
    } else {
        echo '<h6>No jigs found.</h6>';
    }
} 
add_shortcode('reel_post', 'reel_post');


add_action('wp_ajax_reel__show', 'reel__show');
add_action('wp_ajax_nopriv_reel__show', 'reel__show');
function reel__show(){
    $all_user_id = $_POST["user_ID"];    
    $args = array(
        'post_type' => 'reels',
        'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'ASC',
        'meta_query' => array(
            array(
                'key' => 'user_id', 
                'value' => $all_user_id,
                'compare' => '=',
            ),
        ),
    );
    
    $posts = new WP_Query($args);?>
    <?php if ($posts->have_posts()) {?>
        <div class="jigs_post_show">
            
            <div class="sucess_msg"></div>
            <div class="error_msg"></div>
            <div class="row all_jigs_present">
                <?php while ($posts->have_posts()) {
                $posts->the_post();?>
                    <?php $update_jigs = get_field('reels');?>
                        <div class="col-lg-4 col-md-6 col-sm-12 rmve_jigs">
                            <div class="field_wrapper">
                                <div class="video_jigs_all">
                                    <video src="<?php echo $update_jigs['url']; ?>" muted autoplay control loop></video>
                                    <div class="update_fields">
                                        <a href="javascript:void(0);" class="remove_reel" data-index="<?php echo get_the_ID(); ?>"><i class="fas fa-times-circle"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php } ?>
            </div>
        </div>

        <?php wp_reset_postdata();
    } else {
        echo '<h6>No jigs found.</h6>';
    }
    exit();
} 






add_action('wp_ajax_delete_reels', 'delete_reels');
add_action('wp_ajax_nopriv_delete_reels', 'delete_reels');
function delete_reels() {
    $post_ID = $_POST["post_ID"];
    
    wp_delete_post( $post_ID, true);
    
    $response = array("status" => $child_number);
    wp_send_json($response);
    exit;
}



add_action( 'um_registration_complete', 'my_registration_complete', 10, 2 );
function my_registration_complete( $user_id, $args ) {
    $user_info = get_userdata($user_id);
    $username = $user_info->user_login;
    $last_name = $user_info->last_name;
    $user_email = $user_info->user_email;
    $key = 'first_name';
    $single = true;
    $user_first = get_user_meta( $user_id, $key, $single );

        $get_user = array(		
        'post_type' =>  'all_user',
        'post_title'    =>  $user_first,
        'post_status'   => 'publish',
        'post_author'   => $user_id,
    );
    $post_id = wp_insert_post( $get_user );
    update_field('user_email', $user_email, $post_id);
    update_field('user_id', $user_id, $post_id);
    update_field('user_first', $user_first, $post_id);
    update_field('user_last', $last_name, $post_id);
    update_field('package_purchased', "no", $post_id);
}



add_action('wp_ajax_update_prof', 'update_prof');
add_action('wp_ajax_nopriv_update_prof', 'update_prof');
function update_prof(){


    $post_ID = $_POST["post_id"];
    $user_id = $_POST["user_id"];
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $p_number = $_POST["p_number"];
    $U_state = $_POST["U_state"];
    $U_city = $_POST["U_city"];
    $U_country = $_POST["U_country"];
    $location = $_POST["location"];
    $U_bio = $_POST["U_bio"];
    $all_value_user = $_POST["all_value_user"];
    $Update_profile_pic = $_FILES["Update_profile_pic"];


    $post_data = array(
        'ID'           => $post_ID,
        'post_content' => $U_bio,
    );
    wp_update_post($post_data);


    $userdata = array( 
        'ID' => $user_id, 
        'first_name' => $fname, 
        'last_name' => $lname, 
    ); 
     
    wp_update_user($userdata); 

    if(!empty($Update_profile_pic)){
        if ( !function_exists('wp_handle_upload') ) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        
        $movefile = wp_handle_upload($_FILES["Update_profile_pic"], array('test_form' => false));
        if ($movefile && !isset($movefile['error'])) {
            $wp_upload_dir = wp_upload_dir();
            $attachment = array(
                'guid' => $wp_upload_dir['url'] . '/' . basename($movefile['file']),
                'post_mime_type' => $movefile['type'],
                'post_title' => preg_replace('/\.[^.]+$/', "", basename($movefile['file'])),
                'post_content' => ""
            );
            $attach_id = wp_insert_attachment($attachment, $movefile['file']);
            set_post_thumbnail($post_ID, $attach_id);
        }
    }

    update_field("user_first", $fname, $post_ID);
    update_field("user_last", $lname, $post_ID);
    update_field("user_phone", $p_number, $post_ID);
    update_field("state", $U_state, $post_ID);
    update_field("city", $U_city, $post_ID);
    update_field("country", $U_country, $post_ID);
    update_field("user_location", $location , $post_ID);
    update_field("profile_compilation", $all_value_user , $post_ID);

    
    
    
    
    $response = array("post" => "updated");
    wp_send_json($response);
    exit;
}




add_action('wp_login', 'redirect_subscriber_after_first_login', 10, 2);

function redirect_subscriber_after_first_login($user_login, $user) {
    $user_id = $user->ID;

    // Check if this is the first login (using custom user meta)
    $first_login = get_user_meta($user_id, 'first_login', true);

    if (!$first_login) {
        update_user_meta($user_id, 'first_login', true);
        wp_redirect(home_url('/create-profile'));
        exit;
    }
}
// add_action('wp', 'redirect_subscriber_after_login');

// function redirect_subscriber_after_login() {
//     if (is_user_logged_in()) {
//         $user = wp_get_current_user();
//         $id_update = $user->ID;
//         $user_data = get_userdata($id_update);

//         $args = array(
//             'post_type' => 'all_user',
//             'author'    => $id_update,
//             'orderby'   => 'post_date',
//             'order'     => 'ASC',
//         );

//         $current_user_posts = get_posts($args);

//         if (!empty($current_user_posts)) {
//             $all_post_ID = $current_user_posts[0]->ID;
//             $value_all = get_field("profile_compilation", $all_post_ID);

//             // Additional checks
//             if ($value_all && $value_all < 100) {
//                 if (!is_page('create-profile')) {
//                     wp_redirect(home_url('/create-profile'));
//                     exit;
//                 }
//             }
//         }
//     }
// }





add_action('wp_ajax_create_prof', 'create_prof');
add_action('wp_ajax_nopriv_create_prof', 'create_prof');
function create_prof(){

    $post_ID = $_POST["post_id"];
    $user_id = $_POST["user_id"];
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $p_number = $_POST["p_number"];
    $U_state = $_POST["U_state"];
    $U_city = $_POST["U_city"];
    $U_country = $_POST["U_country"];
    $location = $_POST["location"];
    $U_bio = $_POST["U_bio"];
    $all_value_user = $_POST["all_value_user"];
    $Update_profile_pic = $_FILES["Update_profile_pic"];


    $post_data = array(
        'ID'           => $post_ID,
        'post_content' => $U_bio,
    );
    wp_update_post($post_data);


    $userdata = array( 
        'ID' => $user_id, 
        'first_name' => $fname, 
        'last_name' => $lname, 
    ); 
     
    wp_update_user($userdata); 

    if(!empty($Update_profile_pic)){
        if ( !function_exists('wp_handle_upload') ) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        
        $movefile = wp_handle_upload($_FILES["Update_profile_pic"], array('test_form' => false));
        if ($movefile && !isset($movefile['error'])) {
            $wp_upload_dir = wp_upload_dir();
            $attachment = array(
                'guid' => $wp_upload_dir['url'] . '/' . basename($movefile['file']),
                'post_mime_type' => $movefile['type'],
                'post_title' => preg_replace('/\.[^.]+$/', "", basename($movefile['file'])),
                'post_content' => ""
            );
            $attach_id = wp_insert_attachment($attachment, $movefile['file']);
            set_post_thumbnail($post_ID, $attach_id);
        }
    }

    update_field("user_first", $fname, $post_ID);
    update_field("user_last", $lname, $post_ID);
    update_field("user_phone", $p_number, $post_ID);
    update_field("state", $U_state, $post_ID);
    update_field("city", $U_city, $post_ID);
    update_field("country", $U_country, $post_ID);
    update_field("user_location", $location , $post_ID);
    update_field("profile_compilation", $all_value_user , $post_ID);



    // $membership_id = 1; 
    // if (um_user('has_access', $user_id, $membership_id)) { 

    //     wp_redirect(home_url()."/account");

    //  } else { 
    //     wp_redirect(home_url()."/subscriptions");
    // }

    $response = array("post" => "updated");
    wp_send_json($response);

    
    exit;


}






add_action('wp_ajax_package_data_update_post', 'package_data_update_post');
add_action('wp_ajax_nopriv_package_data_update_post', 'package_data_update_post');
function package_data_update_post(){

    $post_ID = $_POST['post_ID'];
    $package_id = $_POST['lid_ID'];
    $package_name = $_POST['package_name'];
    $package_purchased = $_POST['package_purchased'];


    update_field("package_id", $package_id , $post_ID);
    update_field("package_name", $package_name , $post_ID);
    update_field("package_purchased", $package_purchased , $post_ID);


    $response = array("post" => "updated");
    wp_send_json($response);
    exit;
}




add_action("wp", "visit_jigs");

function visit_jigs() {

    global $current_user;

    global $wp;
    $current_url = home_url( add_query_arg( array(), $wp->request ) );


    $id_update = $current_user -> ID;
    $user_data = get_userdata($id_update);

    $args = array(
        'post_type' => 'all_user',
        'author'        =>  $current_user->ID,
        'orderby'       =>  'post_date',
        'order'         =>  'ASC' 
        );

    $current_user_posts = get_posts( $args );

    $all_post_ID = $current_user_posts[0] -> ID;


    $package_purchased = get_field("package_purchased", $current_user_posts[0] -> ID);
    $profile_compilation = get_field("profile_compilation", $current_user_posts[0] -> ID);

        if($current_url === home_url("/upload-jigs")){
            if ($package_purchased === "no") {
                wp_redirect(home_url('/subscriptions'));
                exit;
            }

        } else if($current_url === home_url("/upload-reel")){
            if ($package_purchased === "no") {
                wp_redirect(home_url('/subscriptions'));
                exit;
            }
        }


        if(is_user_logged_in() && $current_url === home_url("/create-profile")){
            if($profile_compilation === "100"){

                wp_redirect(home_url('/account'));
                exit;
            }
        }
}








add_action('wp_ajax_delete_order', 'delete_order');
add_action('wp_ajax_nopriv_delete_order', 'delete_order');
function delete_order(){

    $user_who_purch_id = $_POST["user_who_purch_id"];
    $post_ID = $_POST["post_ID"];


    global $wpdb;

    $table_name = "wp_ihc_user_levels";
    $table_name2 = "wp_ihc_orders";

$delete_from_user_levels= $wpdb->query("DELETE FROM $table_name WHERE user_id=$user_who_purch_id" );

$delete_from_ihc_orders = $wpdb->query("DELETE FROM $table_name2 WHERE uid=$user_who_purch_id" );


update_field("package_purchased","no",$post_ID);

    $response = array("package" => "unsubscribed");
    wp_send_json($response);
    exit;
}


