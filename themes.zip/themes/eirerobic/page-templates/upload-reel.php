<?php
/**
* Template Name: Upload Reels
 */ 
get_header();

global $current_user;
$user_id = $current_user->ID;
?>

<div class="col-md-12">    
    <section class="upload_reels">
        <div class="row_main">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="content_reels">
                        <h4>Upload Reel</h4>
                        <div class="reeluploads">
                            <!-- <form enctype="multipart/form-data" id="dropzone"> -->
                                <input type="hidden" name="user_ID" value="<?php echo $user_id;?>" id="user_ID">
                                <div class="file_upload">
                                    <div class="error_file_video"></div>
                                    <input type="file" class="file__all_reel" id="reel" name="reels_all" accept="video/mp4" aria-invalid="true">
                                    <i class="fa-solid fa-file-video"></i>
                                    <p>Drop your video here or <span>Browse</span></p>
                                    <div class="fileNameContainer"></div>
                                </div>
                                <div class="text_reel">
                                    <input type="text" name="reel_title" id="reel_title" placeholder="Add title" class="form-control titleS_rl" aria-invalid="true">
                                    <div class="error_title"></div>
                                </div> 
                                <div class="submit_btn_reel">
                                    <button  id="upload_reel" class="form-control btn_sbtn_rl">Upload</button>
                                </div>     
                                <div class="sucess_msg"></div>
                                <div class="error_msg"></div>
                            <!-- </form> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row_update_jigs">
            <div class="col-md-12">
                <h4>Uploaded Jigs</h4>
                <div class="jigs_udate_all_time">
                    <?php echo do_shortcode("[reel_post]"); ?>
                </div>
            </div>
        </div>
    </section>
</div>


<?php get_footer(); ?>

<script>
//     jQuery(document).ready(function() {
//         jQuery('#reel').change(function() {
//         var fileNameContainer = jQuery('#fileNameContainer');
//         var fileName = jQuery(this).val().split('\\').pop(); // Get the file name

//         // Display the file name in the specified container
//         fileNameContainer.html('<p>Uploaded File: ' + fileName + '</p>');
//     });
// });


jQuery(document).ready(function() {
    jQuery('.file__all_reel').change(function() {
        var imageContainer = jQuery('.fileNameContainer')[0];
        var fileInput = jQuery(this)[0];

        if (fileInput.files && fileInput.files[0] && fileInput.files[0].type === 'video/mp4') {
            var reader = new FileReader();

            reader.onload = function(e) {
                imageContainer.innerHTML = '<video loop autoplay muted><source src="' + e.target.result + '" type="video/mp4"></video>';
            };

            reader.readAsDataURL(fileInput.files[0]);
        } else {
            imageContainer.innerHTML = '';
            // alert('Please select a valid MP4 video file.');
        }
    });
});

</script>