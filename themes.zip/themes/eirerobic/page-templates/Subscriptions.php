<?php
/**
* Template Name: Subscriptions
 */ 
get_header();

global $current_user;
$id_update = $current_user -> ID;
$user_data = get_userdata($id_update);

$prefix = $wpdb->prefix;
$table_name = $prefix . 'ihc_orders';
$table_name2 = $prefix . 'ihc_user_levels';

$user_roles = $user_data->roles;
$user_role_name = $user_roles[0];

$membership_level = $wpdb->get_var($wpdb->prepare( "SELECT lid FROM {$table_name} WHERE `uid` = {$id_update};", $id_update)); 

$order_ID = $wpdb->get_var($wpdb->prepare( "SELECT id FROM {$table_name} WHERE `uid` = {$id_update};", $id_update)); 

$membership_user = $wpdb->get_var($wpdb->prepare( "SELECT uid FROM {$table_name} WHERE `lid` = {$membership_level} AND `uid` = {$id_update};", $membership_level,
$id_update
)); 

$package_name = $wpdb->get_var($wpdb->prepare("SELECT label FROM `wp_ihc_memberships` WHERE id=1" ));

$args = array(
    'post_type' => 'all_user',
    'author'        =>  $current_user->ID,
    'orderby'       =>  'post_date',
    'order'         =>  'ASC' 
    );

$current_user_posts = get_posts( $args );
$all_post_ID = $current_user_posts[0] -> ID;
?>


    
<div class="col-md-12 col-sm-12">
    <section class="Subscriptions">
        <div class="subs_row">
            <div class="row">
                <div class="col-lg-8 col-md-12 col-sm-12">
                    <h4>Subscriptions To Add Reels And Jigs</h4>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div class="btn_Skip">
                        <a href="<?php echo home_url();?>/account">Skip for now</a>
                    </div> 
                </div>
            </div>
            <div class="packages_all">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="content_package">
                            <h5>Step Instruction</h5>
                            <div class="prices_package">
                                <h3>$89.00</h3>
                                <p>Subscribe to Step Instruction</p>
                            </div>
                            <div class="list_packages">
                                <ul>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                </ul>
                            </div>
                            <div class="btn__submit_pakage">
                                <a href="javascript:void(0);">Subscribe</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="content_package">
                            <h5>Complete Workout</h5>
                            <div class="prices_package">
                                <h3>$100.00</h3>
                                <p>Subscribe to Step Instruction</p>
                            </div>
                            <div class="list_packages">
                                <ul>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                </ul>
                            </div>
                            <div class="btn__submit_pakage">
                                <?php if (is_user_logged_in()) { 

                                        if($user_role_name === 'subscriber' || $user_role_name === 'administrator'){ ?>
                                            
                                            <a data-post-id = "<?php echo $all_post_ID;?>" data-user-who-purch-id="<?php echo $membership_user?>" data-order-id="<?php echo $order_ID;?>" data-pckg-name="<?php echo $package_name;?>" data-package-id="<?php echo $membership_level?>" id="subscribe_btn" class="subscribe_btn delete" href="<?php echo home_url();?>/checkout-page/?lid=1">Subscribe</a>
                                            <span></span>

                                        <?php } else{ ?>
                                            <a href="javascript:void(0);">Subscribe</a>
                                       <?php } 
                                    }else{ ?>
                                        <a href="<?php echo home_url();?>/login">Subscribe</a>
                                <?php } ?>                        
                                    

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="content_package">
                            <h5>Reels And Jigs</h5>
                            <div class="prices_package">
                                <h3>$29.00</h3>
                                <p>Subscribe to Step Instruction</p>
                            </div>
                            <div class="list_packages">
                                <ul>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                    <li>Lorem ipsum dolor sit amet</li>
                                </ul>
                            </div>
                            <div class="btn__submit_pakage">
                            <?php if (is_user_logged_in()) { 

                                if($user_role_name === 'subscriber' || $user_role_name === 'administrator'){ ?>
                                    
                                    <a data-user-who-purch-ID="1" data-order-id="15" data-pckg-name="<?php echo $package_name;?>" data-package-ID="2" id="subscribe_btn" class="subscribe_btn delete" href="javascript:void(0);">Subscribe</a>

                                <?php } else{ ?>
                                    <a href="javascript:void(0);">Subscribe</a>
                                <?php } 
                                }else{ ?>
                                <a href="<?php echo home_url();?>/login">Subscribe</a>
                                <?php } ?> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<?php get_footer();

