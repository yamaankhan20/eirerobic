<?php
/**
* Template Name: checkout page
 */ 
get_header();

$pack_get = $_GET["lid"];

global $current_user;
$id_update = $current_user -> ID;
$user_data = get_userdata($id_update);

$args = array(
    'post_type' => 'all_user',
    'author'        =>  $id_update,
    'orderby'       =>  'post_date',
    'order'         =>  'ASC' 
    );

$current_user_posts = get_posts( $args );

$all_post_ID = $current_user_posts[0] -> ID;


$prefix = $wpdb->prefix;
$table_name = $prefix . 'ihc_orders';
$user_roles = $user_data->roles;
$user_role_name = $user_roles[0];

$membership_level = $wpdb->get_var($wpdb->prepare( "SELECT lid FROM {$table_name} WHERE `uid` = {$id_update};", $id_update)); 

$membership_user = $wpdb->get_var($wpdb->prepare( "SELECT uid FROM {$table_name} WHERE `lid` = {$membership_level} AND `uid` = {$id_update};", $membership_level,
$id_update
)); 

$status_package = $wpdb->get_var($wpdb->prepare( "SELECT status FROM {$table_name} WHERE `uid` = {$id_update};", $id_update));

$package_name = $wpdb->get_var($wpdb->prepare("SELECT name FROM `wp_ihc_memberships` WHERE id=1"));


?>

    

<div class="page_checkout">
    <section class="checkout_sec">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <input type="hidden" value="<?php echo $membership_level?>" id="package_id">
                    <input type="hidden" value="<?php echo $membership_user?>" id="user_purchased_id">
                    <input type="hidden" value="<?php echo $package_name?>" id="package_name">
                    <input type="hidden" value="<?php echo $all_post_ID?>" id="post_ID">
                    <input type="hidden" value="<?php echo $pack_get?>" id="lid_ID">
                    <input type="hidden" value="<?php echo $status_package?>" id="status_package">

                    <?php echo do_shortcode("[ihc-checkout-page]");?>
                    <div class="msg_span">
                        <span></span>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<?php get_footer();

