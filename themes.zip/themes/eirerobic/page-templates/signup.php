<?php
/**
* Template Name: signup page
 */ 
get_header();
?>

    

<div class="page_login">
    <section class="log_sec sign_up">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 frst_log">
                    <div class="logo_header">
                        <a href="<?php echo home_url();?>"><img src="<?php echo home_url();?>/jigs/wp-content/uploads/2023/01/image.png" alt="No Image Found"></a>
                    </div>
                    <div class="content_login">
                        <h4>Sign Up</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing.</p>
                    </div>
                    <div class="log_shortcode">
                        <?php echo do_shortcode("[ultimatemember form_id='399']");?>
                        <?php if (!is_user_logged_in()) { ?>
                           <p>Don't have an account? <a href="<?php echo home_url();?>/Login">Login</a></p> 
                        <?php }?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 scnd_log">
                    <div class="img_login">
                        <img src="<?php echo home_url();?>/jigs/wp-content/uploads/2023/12/Group-15227.png" alt="No Image Found">
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<?php get_footer();

