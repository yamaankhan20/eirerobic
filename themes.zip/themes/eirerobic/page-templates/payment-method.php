<?php
/**
* Template Name: Payment Method
 */ 
get_header();
?>

    

<div class="col-md-12 col-sm-12">
    <section class="payment_sec">
        <div class="pay_row">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <h4>Payment Method</h4>
                    <div class="payment_forms">
                        <div class="row">
                            <div class="col-lg-8 col-md-12 col-sm-12">
                                <div class="payment_details">
                                    <h5>Credit card details</h5>
                                    <form action="" class="row paym_frm">
                                        <div class="col-lg-12 col-md-12 col-sm-12 card_number">
                                            <label>Credit card number *</label>
                                            <i class="fa-solid fa-credit-card"></i>
                                            <input type="text" name="cardnumber" id="cardnumber" class="form-control feild__all">
                                        </div>
                                        <div class="col-md-12 col-lg-8 col-sm-12">
                                            <label>Expiry date *</label>
                                            <div class="month_payment_selection">
                                                <select name="Month" id="Month" class="form-control">
                                                    <option value="jan">january</option>
                                                    <option value="feb">febuary</option>
                                                    <option value="mar">march</option>
                                                    <option value="apr">april</option>
                                                    <option value="may">may</option>
                                                    <option value="june">june</option>
                                                    <option value="july">july</option>
                                                    <option value="aug">august</option>
                                                    <option value="sept">september</option>
                                                    <option value="oct">october</option>
                                                    <option value="nov">november</option>
                                                    <option value="dec">december</option>
                                                </select>
                                                <select name="Year" id="Year" class="form-control">
                                                    <option value="2024">2024</option>
                                                    <option value="2023">2023</option>
                                                    <option value="2022">2022</option>
                                                    <option value="2021">2021</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 col-md-12 col-sm-12">
                                            <label>CVV *</label>
                                            <input type="number" name="CVV" id="CVV" placeholder="CVV" class="form-control feild__all">
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 crd_hoder">
                                            <label>Card holder name *</label>
                                            <input type="text" name="Card_holder" id="Card_holder" placeholder="Card holder" class="form-control feild__all">
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <input type="submit" value="Pay Now" id="done_payment">
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-12 col-sm-12">
                                <div class="order_sumary">
                                    <h3>Order Summary</h3>
                                    <div class="subscriber_name">
                                        <h6>Subscription name</h6>
                                        <span>$100.00 / month</span>
                                    </div>
                                    <p>Subscription to complete workout (reel's & jig's included)</p>
                                    <div class="total_amout_paid">
                                        <h6>Total</h6>
                                        <span>$100.00</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<?php get_footer();

