<?php
/**
* Template Name: Upload Jigs
 */ 
get_header();

global $current_user;
$all_user_id = $current_user->ID; 
$all_user_name = $current_user->display_name; 

?>

<input type="hidden" id="USER_id" value="<?php echo $all_user_id;?>">
<input type="hidden" id="USER_name" value="<?php echo $all_user_name;?>">


<div class="col-md-12">    
    <section class="upload_reels">
        <div class="row_main">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="content_reels">
                        <h4>Upload Jigs</h4>
                        <div class="reeluploads">
                            <!-- <form enctype="multipart/form-data"> -->
                                <div class="file_upload">
                                    <input type="file" class="file__all_reel" id="Jigs" name="jigs_all" accept="video/mp4">
                                    <i class="fa-solid fa-file-video"></i>
                                    <p>Drop your video here or <span>Browse</span></p>
                                    <div class="fileNameContainer"></div>
                                </div>
                                <div class="text_reel">
                                    <input type="text" value="<?php echo $all_user_name;?>" name="jigs_title" id="jigs_title" placeholder="Add title" class="form-control titleS_rl disabled" disabled>
                                </div> 
                                <div class="submit_btn_reel">
                                    <button id="upload_jogs" class="form-control btn_sbtn_rl">Upload</button>
                                </div>     
                                <div class="sucess_msg"></div>
                                <div class="error_msg"></div>
                            <!-- </form> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row_update_jigs">
            <div class="col-md-12">
                <h4>Uploaded Jigs</h4>
                <div class="jigs_udate_all_time">
                    <?php echo do_shortcode("[jigs_post]"); ?>
                </div>
                
            </div>
        </div>
    </section>
</div>


<?php get_footer(); ?>

<script>

jQuery(document).ready(function() {
    jQuery('.file__all_reel').change(function() {
        var imageContainer = jQuery('.fileNameContainer')[0];
        var fileInput = jQuery(this)[0];

        if (fileInput.files && fileInput.files[0] && fileInput.files[0].type === 'video/mp4') {
            var reader = new FileReader();

            reader.onload = function(e) {
                imageContainer.innerHTML = '<video loop autoplay muted><source src="' + e.target.result + '" type="video/mp4"></video>';
            };

            reader.readAsDataURL(fileInput.files[0]);
        } else {
            imageContainer.innerHTML = '';
            alert('Please select a valid MP4 video file.');
        }
    });
});


jQuery(document).ready(function() {
   

    jQuery('.repeater_field').change(function() {
        var fieldWrapper = jQuery(this).closest('.field_wrapper');
        var imageContainer = fieldWrapper.find('.jigs_updt_video');
        var fileInput = this;
        var recent = fieldWrapper.find(".recent_video");
        var recent_new = jQuery(".constant_video").val();
        

        if (fileInput.files && fileInput.files[0] && fileInput.files[0].type === 'video/mp4') {
            var objectURL = URL.createObjectURL(fileInput.files[0]);
            var reader = new FileReader();

            reader.onload = function(e) {
                imageContainer.html('<video muted><source src="' + e.target.result + '" type="video/mp4"></video>');
                recent.attr("data-value", objectURL);
            };
            
            reader.readAsDataURL(fileInput.files[0]);
            
        } else {
            imageContainer.html('');
            recent.attr("data-value",recent_new);
        }

        
        
    });
});





</script>