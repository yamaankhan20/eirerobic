<?php
/**
* Template Name: login page
 */ 
get_header();
?>

    

<div class="page_login">
    <section class="log_sec">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-12 frst_log">
                    <div class="logo_header">
                        <a href="<?php echo home_url();?>"><img src="<?php echo home_url();?>/jigs/wp-content/uploads/2023/01/image.png" alt="No Image Found"></a>
                    </div>
                    <div class="content_login">
                        <h4>Welcome Back!</h4>
                        <p>Enter your credentials to continue</p>
                    </div>
                    <div class="log_shortcode">
                        <?php echo do_shortcode("[ultimatemember form_id='400']");?>
                        <?php if (!is_user_logged_in()) { ?>
                            <p>Don't have an account? <a href="<?php echo home_url();?>/sign-up">Sign up</a></p> 
                        <?php }?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 scnd_log">
                    <div class="img_login">
                        <img src="<?php echo home_url();?>/jigs/wp-content/uploads/2023/12/Group-15227.png" alt="No Image Found">
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<?php get_footer();

