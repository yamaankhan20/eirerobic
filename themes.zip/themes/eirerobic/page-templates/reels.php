<?php
/**
* Template Name: Reels
 */ 
get_header();

global $current_user;
$user_id = $current_user->ID;
$args2 = array(
    'post_type' => 'all_user',
    'author'        =>  $user_id,
    'orderby'       =>  'post_date',
    'order'         =>  'ASC' 
);

$all_POSt = get_posts( $args2 );
$package_purchased = get_field("package_purchased", $all_POSt[0] -> ID);

?>
    

    
<div class="col-md-12 col-sm-12">
    <section class="reel_view_sec">
        <div class="row_reel_view">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="jigs_show">
                           <?php echo do_shortcode("[jigs_short]");?>
                    </div>
                </div>
            </div>    
            <div class="main_reel_all_scroll">
                <div class="row slider">
                    <?php echo do_shortcode("[reelS_short]");?>
                </div>
            </div> 
            <div class="add_reel_new">
            <?php if(!is_user_logged_in()){ ?>
                <a href="<?php echo home_url();?>/login"><i class="fa-solid fa-plus"></i> Add Reel</a>
            <?php }else{ 
                if($package_purchased === "no"){ ?>
                        <a href="<?php echo home_url();?>/subscriptions/"><i class="fa-solid fa-plus"></i> Add Reel</a>
                    <?php }else{ ?>
                        <a href="<?php echo home_url();?>/upload-reel/"><i class="fa-solid fa-plus"></i> Add Reel</a>
                    <?php } ?>
            <?php } ?>
            </div>  
        </div>
    </section>
</div>

<div class="pop_jigs">
    <div class="jigs_over">
        <a href="javascript:void(0);">
            <svg xmlns="http://www.w3.org/2000/svg" height="16" width="12" viewBox="0 0 384 512"><path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"/></svg>
        </a>
        <div class="all_jigs_here_popup">

        </div>
    </div>
</div>
<?php get_footer();

