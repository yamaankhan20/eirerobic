<?php
/**
* Template Name: Create profile
 */ 
get_header();

global $current_user;


$id_update = $current_user -> ID;
$user_data = get_userdata($id_update);

$args = array(
    'post_type' => 'all_user',
    'author'        =>  $current_user->ID,
    'orderby'       =>  'post_date',
    'order'         =>  'ASC' 
    );

$current_user_posts = get_posts( $args );

$all_post_ID = $current_user_posts[0] -> ID;




?>

<div class="logo_header_prof">
    <a href="<?php echo home_url();?>"><img src="<?php echo home_url();?>/jigs/wp-content/uploads/2023/01/image.png" alt="No Image Found"></a>
</div>
<div class="col-md-12">
    <section class="profile_complete">
        <div class="pro_row">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="content_profile">
                        <h4>Complete Your Profile</h4>
                        <p>Lorem Ipsum is simply dummy text of the printing.</p>
                        <div class="sucess_msg"></div>
                        <div class="error_msg"></div>
                    </div>
                    <div class="main_prof_setting">
                        <!-- <form action="" method="post" enctype="multipart/form-data"> -->
                            <input type="hidden" value="<?php echo $all_post_ID;?>" id="post_ID">
                            <input type="hidden" id="user_id" value="<?php echo $id_update;?>">

                            <div class="row">
                                <div class="col-lg-4 col-md-12 col-sm-12">
                                    <div class="profile_pic_main">
                                        <input type="file" class="profile__pic" id="profile_pic" name="prof_pic" accept="image/*">
                                        <input type="hidden" value="10" id="image_value">
                                        <div id="imageContainer"></div>
                                        <i class="fa-solid fa-plus"></i>
                                        <p>Drop your profile picture here or <span>Browse</span></p>
                                    </div>
                                </div>
                                <div class="col-lg-8 col-md-12 col-sm-12">
                                    <div class="form_names">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-12 col-sm-12">
                                                <label for="firstname">First name</label>
                                                <input type="text" value="<?php echo $user_data -> first_name;?>" id="f_name" placeholder="First name" class="form-control input_profile">
                                                <input type="hidden" value="10" id="f_value">
                                            </div>
                                            <div class="col-lg-6 col-md-12 col-sm-12">
                                                <label for="lastname">Last name</label>
                                                <input type="text" value="<?php echo $user_data -> last_name;?>" id="l_name" placeholder="Last name" class="form-control input_profile">
                                                <input type="hidden" value="10" id="l_value">
                                            </div>
                                            <div class="col-lg-6 col-md-12 col-sm-12">
                                                <label for="emailaddress">Email address</label>
                                                <input type="email" value="<?php echo $user_data -> user_email;?>" id="email_address" placeholder="Enter your email" class="form-control input_profile disabled" disabled>
                                                <input type="hidden" value="10" id="email_value">
                                            </div>
                                            <div class="col-lg-6 col-md-12 col-sm-12">
                                                <label for="phonenumber">Phone number</label>
                                                <input type="number" value="<?php echo get_field("user_phone", $all_post_ID);?>" id="p_number" placeholder="Phone number" class="form-control input_profile">
                                                <input type="hidden" value="10" id="phone_value">
                                            </div>
                                            <div class="col-lg-3 col-md-12 col-sm-12">
                                                <label for="State">State</label>
                                                <input type="text" id="U_state" value="<?php echo get_field("state", $all_post_ID);?>" placeholder="State" class="form-control input_profile">
                                                <input type="hidden" value="10" id="state_value">
                                            </div>
                                            <div class="col-lg-3 col-md-12 col-sm-12">
                                                <label for="City">City</label>
                                                <input type="text" value="<?php echo get_field("city", $all_post_ID);?>" id="U_city" placeholder="City" class="form-control input_profile">
                                                <input type="hidden" value="10" id="city_value">
                                            </div>
                                            <div class="col-lg-3 col-md-12 col-sm-12">
                                                <label for="Country">Country</label>
                                                <input type="text" value="<?php echo get_field("country", $all_post_ID);?>" id="U_country" placeholder="Country" class="form-control input_profile">
                                                <input type="hidden" value="10" id="country_value">
                                            </div>
                                            <div class="col-lg-3 col-md-12 col-sm-12">
                                                <label for="Country">location</label>
                                                <input type="text" value="<?php echo get_field("user_location", $all_post_ID);?>" id="location" placeholder="location" class="form-control input_profile">
                                                <input type="hidden" value="10" id="location_value">
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12">
                                                <label for="Bio">Bio</label>
                                                <textarea name="Bio" id="U_bio" placeholder="Bio" class="form-control txt_bio"><?php echo $current_user_posts[0] ->post_content;?></textarea>
                                                <input type="hidden" value="10" id="bio_value">
                                            </div>
                                            <div class="col-md-12 col-sm-12">
                                                <button value="Set up" class="Setup_prof" id="Set_up_prof">Set up</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <!-- </form> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>



<?php get_footer(); ?>

<script>
    jQuery(document).ready(function() {
    jQuery('#profile_pic').change(function() {
        var imageContainer = jQuery('#imageContainer')[0];
        var fileInput = jQuery(this)[0];

        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                // Display the selected image in the specified container
                imageContainer.innerHTML = '<img src="' + e.target.result + '">';
            };

            reader.readAsDataURL(fileInput.files[0]);
        } else {
            imageContainer.innerHTML = ''; // Clear the container if no file is selected
        }
    });
});
</script>

