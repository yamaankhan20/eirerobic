<?php
/**
* Template Name: dashoard
 */ 
get_header();
global $current_user;
global $wpdb;

$id_update = $current_user -> ID;



$prefix = $wpdb->prefix;
$table_name = $prefix . 'ihc_orders';

$membership_level = $wpdb->get_var($wpdb->prepare( "SELECT lid FROM {$table_name} WHERE `uid` = {$id_update};", $id_update)); 

$membership_id = $wpdb->get_var($wpdb->prepare( "SELECT uid FROM {$table_name} WHERE `uid` = {$id_update};", $id_update)); 

$membership_user = $wpdb->get_var($wpdb->prepare( "SELECT uid FROM {$table_name} WHERE `lid` = {$membership_level} AND `uid` = {$id_update};", $membership_level,
$id_update
)); 
$membership_date_order = $wpdb->get_var($wpdb->prepare( "SELECT create_date FROM {$table_name} WHERE `uid` = {$id_update};", $id_update));

$package_name = $wpdb->get_var($wpdb->prepare("SELECT label FROM `wp_ihc_memberships` WHERE id=1" ));
$package_price = $wpdb->get_var($wpdb->prepare("SELECT price FROM `wp_ihc_memberships` WHERE id=1" ));

$args = array(
    'post_type' => 'all_user',
    'author'        =>  $current_user->ID,
    'orderby'       =>  'post_date',
    'order'         =>  'ASC' 
    );

$current_user_posts = get_posts( $args );
$all_post_ID = $current_user_posts[0] -> ID;





?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />



<div class="col-md-12">
    <div class="dashoard__admin">
<input type="hidden" id="profile_value" value="<?php echo get_field("profile_compilation", $all_post_ID);?>">
        <section class="container" id="user-vol">
            <div class="row">
                <div class="col-lg-7">
                    <div class="user-vol-col1">
                        <div class="user-profilePic">
                        <?php if( get_the_post_thumbnail_url($all_post_ID,'full') ){
                            $featured_img_url = get_the_post_thumbnail_url($all_post_ID,'small')
                            ?>
                            <img  src="<?php echo $featured_img_url;?>">
                        <?php }else{ ?>
                            <img src="<?php echo home_url();?>/jigs/wp-content/uploads/2024/01/default_avatar.jpg">
                        <?php } ?>
                        </div>
                        <div class="user-bio">
                            <h2><?php echo $current_user -> display_name;?></h2>
                            <ul>
                                <li><span class="user-adr-label">Email:</span> <a href="mailto:<?php echo $current_user -> user_email;?>"><span class="user-adr"><?php echo $current_user -> user_email;?></span></a></li>
                                <li><span class="user-adr-label">Location:</span> <span class="user-adr"><?php echo get_field("user_location", $current_user_posts[0] -> ID); ?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="user-vol-col2">
                        <a id="user-edit-btn" href="<?php echo home_url();?>/edit-profile">Edit</a>

                        <div class="profile-compleation-box">

                            <div class="progress-screen">
                                <p class="progress-bar-label">Profile Compilation:</p>
                                <span id="barValue"></span>
                            </div>

                            <div id="user-progress">
                                <div id="UserBar"></div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="course-details" class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="course-title">Course details</h1>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="lesson_progress">
                        <div class="lesson-check-wrapper">
                            <div class="lesson-check-dot">
                                <span>1</span>
                                <span>2</span>
                                <span>3</span>
                                <span>4</span>
                                <span>5</span>
                                <span>6</span>
                            </div>
                        </div>
                        <div id="lesson-progress">
                            <div id="LessonBar"></div>
                        </div>
                        <div class="lesson-list-wrapper">
                            <div class="lesson-list">
                                <span>Lesson 1</span>
                                <span>Lesson 2</span>
                                <span>Lesson 3</span>
                                <span>Lesson 4</span>
                                <span>Lesson 5</span>
                                <span>Lesson 6</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6 dance-col">
                    <h2>Dance</h2>
                    <p><?php echo $current_user_posts[0] -> post_content;?></p>
                </div>

                <div class="col-lg-6 lesson-col">
                    <h1>Lessons</h1>

                    <div class="accordion accordion-flush lesson-acc-box" id="accordionFlushExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingOne">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                <p class="course-btn-label">Lesson 1</p>
                                <div class="lesson-detail">
                                    <span class="video-count">3 Videos</span>
                                    <span class="video-times"><i class="fa-solid fa-clock"></i>14 m 35 s</span>
                                </div>
                            </button>
                            </h2>
                            <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingTwo">
                            <button class="btn btn- accordion-button collapsed disabled" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                <p class="course-btn-label">Lesson 2</p>
                                <div class="lesson-detail">
                                    <span class="video-count">3 Videos</span>
                                    <span class="video-times"><i class="fa-solid fa-clock"></i>14 m 35 s</span>
                                </div>                        
                            </button>
                            </h2>
                            <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingThree">
                            <button class="btn btn- accordion-button collapsed disabled" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                                <p class="course-btn-label">Lesson 3</p>
                                <div class="lesson-detail">
                                    <span class="video-count">3 Videos</span>
                                    <span class="video-times"><i class="fa-solid fa-clock"></i>14 m 35 s</span>
                                </div>                        
                            </button>
                            </h2>
                            <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="flush-headingFour">
                            <button class="btn btn- accordion-button collapsed disabled" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
                                <p class="course-btn-label">Lesson 4</p>
                                <div class="lesson-detail">
                                    <span class="video-count">3 Videos</span>
                                    <span class="video-times"><i class="fa-solid fa-clock"></i>14 m 35 s</span>
                                </div>                        
                            </button>
                            </h2>
                            <div id="flush-collapseFour" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="subscription-sec container">
            <div class="row">
                <div class="col-lg-6 brd-rght">
                    <div class="subs-price-box">
                        <h5>Subscription</h5>
                            <?php  
                            if((string)$membership_id === (string)$id_update){ ?>
                                <h4><?php echo $package_name;?></h4>
                                <h3>$<?php echo $package_price;?></h3>
                                <p>Subscribe to <?php echo $package_name;?> (reel's & jig's included)</p>
                            <?php }else{
                                echo "No Package Found";
                            } ?>
                            
                    </div>
                </div>
                <!-- <div class="col-lg-4">
                    <div class="subs-listing">
                        <ul>
                            <li>Lorem ipsum dolor sit amet</li>
                            <li>Lorem ipsum dolor sit amet</li>
                            <li>Lorem ipsum dolor sit amet</li>
                            <li>Lorem ipsum dolor sit amet</li>
                            <li>Lorem ipsum dolor sit amet</li>
                        </ul>
                    </div>
                </div> -->
                <div class="col-lg-6">
                    <div class="subs-action-box">
                        <p>Date <br> <?php
                        $date_crete = date("d F Y", strtotime($membership_date_order));
                        if((string)$membership_id === (string)$id_update){ 

                            if(!$date_crete){
                                echo "no date Found";
                            }else{
                                echo $date_crete;
                            }
                        }else{
                            echo "No Package Found";
                        } ?></p>
                        <a id="subs-upgrade-btn"href="<?php echo home_url();?>/subscription">Upgrade</a>
                    </div>
                </div>
            </div>

        </section>


</div>
</div>




<script >
    
    // User Progress bar

    function move() {
        setTimeout(() => {
            var get_with = jQuery("#LessonBar").width();
            var parentWidth = $("#LessonBar").parent().width();
            var cala = (get_with / parentWidth) * 100;
            console.log("done:", cala.toFixed(0),);    
            }, 2000);

        // User Progress bar
        var elem = document.getElementById("UserBar");
        var width = 1;
        var id = setInterval(frame, 20);

         // Lesson Progress bar
        var elemLesson = document.getElementById("LessonBar");
        var widthLesson = 1;
        var id = setInterval(frameLesson, 20);

        // Lesson Progress bar frame
        function frameLesson() {
            if (widthLesson >= 30) {
                clearInterval(id);
                
                
            } else {
                widthLesson++;
                elemLesson.style.width = widthLesson + "%";
                // document.getElementById("barValue").innerHTML = width + "%"
            }
        }

            // User Progress bar frame
        function frame() {
            var get_value = jQuery("#profile_value").val();
            if (width >= get_value) {
                clearInterval(id);
            } else {
                width++;
                elem.style.width = width + "%";
                document.getElementById("barValue").innerHTML = width + "%"
            }
        }
    }

    var body = document.getElementsByTagName("body")[0]; 
    body.addEventListener("load", move(), false); 
 
 jQuery(document).ready(function () {
    
    
 })   ;

    

</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js" integrity="sha512-GWzVrcGlo0TxTRvz9ttioyYJ+Wwk9Ck0G81D+eO63BaqHaJ3YZX9wuqjwgfcV/MrB2PhaVX9DkYVhbFpStnqpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<?php get_footer(); ?>
